import {
  boolean,
  index,
  integer,
  numeric,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    username: text("username").notNull().unique(),
    displayName: text("display_name").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("users_username_idx").on(t.username)],
);

export const sessions = pgTable(
  "sessions",
  {
    token: text("token").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const authors = pgTable(
  "authors",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: text("name").notNull(),
    slug: text("slug").notNull().unique(),
    bio: text("bio").notNull().default(""),
    born: text("born").notNull().default(""),
    nationality: text("nationality").notNull().default(""),
    photoUrl: text("photo_url"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("authors_name_idx").on(t.name)],
);

export const books = pgTable(
  "books",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    title: text("title").notNull(),
    slug: text("slug").notNull().unique(),
    authorId: uuid("author_id")
      .notNull()
      .references(() => authors.id, { onDelete: "cascade" }),
    description: text("description").notNull().default(""),
    coverUrl: text("cover_url"),
    publishedYear: integer("published_year"),
    pages: integer("pages"),
    genres: text("genres").array().notNull().default([]),
    heat: integer("heat").notNull().default(5),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    index("books_author_idx").on(t.authorId),
    index("books_title_idx").on(t.title),
  ],
);

export type LogStatus = "read" | "reading" | "want";

export const logs = pgTable(
  "logs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    bookId: uuid("book_id")
      .notNull()
      .references(() => books.id, { onDelete: "cascade" }),
    status: text("status").$type<LogStatus>().notNull().default("read"),
    rating: numeric("rating", { precision: 2, scale: 1 }),
    liked: boolean("liked").notNull().default(false),
    review: text("review"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("logs_user_book_unique").on(t.userId, t.bookId),
    index("logs_book_idx").on(t.bookId),
    index("logs_user_idx").on(t.userId),
    index("logs_created_idx").on(t.createdAt),
  ],
);

export const follows = pgTable(
  "follows",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    followerId: uuid("follower_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    followeeId: uuid("followee_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("follows_pair_unique").on(t.followerId, t.followeeId),
    index("follows_follower_idx").on(t.followerId),
    index("follows_followee_idx").on(t.followeeId),
  ],
);

export type User = typeof users.$inferSelect;
export type Author = typeof authors.$inferSelect;
export type Book = typeof books.$inferSelect;
export type Log = typeof logs.$inferSelect;
export type Follow = typeof follows.$inferSelect;
