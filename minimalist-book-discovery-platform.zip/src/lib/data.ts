import { cache } from "react";
import { db } from "@/db";
import { authors, books, follows, logs, users } from "@/db/schema";
import { and, eq, desc, isNotNull, sql } from "drizzle-orm";
import type { Author, Book, Follow, Log, User } from "@/db/schema";

export type BookMeta = Book & {
  author: Author;
  readCount: number;
  wantCount: number;
  readingCount: number;
  ratingCount: number;
  avgRating: number | null;
  recentCount: number; // logs in last 7 days
  reviewCount: number;
};

export type ReviewWithMeta = {
  log: Log;
  book: BookMeta;
  user: User;
};

export type Library = {
  books: Map<string, BookMeta>;
  authors: Map<string, Author>;
  users: Map<string, User>;
  allLogs: Log[];
  logsByUser: Map<string, Log[]>;
};

export const getLibrary = cache(async (): Promise<Library> => {
  const [allBooks, allAuthors, allLogs, allUsers] = await Promise.all([
    db.select().from(books),
    db.select().from(authors),
    db.select().from(logs),
    db.select().from(users),
  ]);

  const authorById = new Map(allAuthors.map((a) => [a.id, a]));
  const userById = new Map(allUsers.map((u) => [u.id, u]));

  const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
  const stat = new Map<
    string,
    {
      read: number;
      want: number;
      reading: number;
      ratings: number[];
      recent: number;
      reviews: number;
    }
  >();
  const logsByUser = new Map<string, Log[]>();

  for (const l of allLogs) {
    let s = stat.get(l.bookId);
    if (!s) {
      s = { read: 0, want: 0, reading: 0, ratings: [], recent: 0, reviews: 0 };
      stat.set(l.bookId, s);
    }
    if (l.status === "read") s.read++;
    if (l.status === "want") s.want++;
    if (l.status === "reading") s.reading++;
    if (l.rating) s.ratings.push(parseFloat(l.rating));
    if (l.createdAt.getTime() > weekAgo) s.recent++;
    if (l.review) s.reviews++;

    const list = logsByUser.get(l.userId) ?? [];
    list.push(l);
    logsByUser.set(l.userId, list);
  }

  const bookMap = new Map<string, BookMeta>();
  for (const b of allBooks) {
    const s = stat.get(b.id);
    const ratings = s?.ratings ?? [];
    const avg = ratings.length
      ? ratings.reduce((a, c) => a + c, 0) / ratings.length
      : null;
    bookMap.set(b.id, {
      ...b,
      author: authorById.get(b.authorId)!,
      readCount: s?.read ?? 0,
      wantCount: s?.want ?? 0,
      readingCount: s?.reading ?? 0,
      ratingCount: ratings.length,
      avgRating: avg,
      recentCount: s?.recent ?? 0,
      reviewCount: s?.reviews ?? 0,
    });
  }

  return {
    books: bookMap,
    authors: authorById,
    users: userById,
    allLogs,
    logsByUser,
  };
});

export function popularity(b: BookMeta) {
  return b.readCount * 1.4 + b.wantCount * 0.8 + b.heat * 1.2;
}

export async function getPopularThisWeek(limit = 12): Promise<BookMeta[]> {
  const lib = await getLibrary();
  return [...lib.books.values()]
    .filter((b) => b.ratingCount >= 1)
    .sort((a, z) => {
      if (z.recentCount !== a.recentCount) return z.recentCount - a.recentCount;
      return popularity(z) - popularity(a);
    })
    .slice(0, limit);
}

export async function getTopRated(limit = 12): Promise<BookMeta[]> {
  const lib = await getLibrary();
  return [...lib.books.values()]
    .filter((b) => b.ratingCount >= 3)
    .sort((a, z) => {
      const za = z.avgRating ?? 0;
      const aa = a.avgRating ?? 0;
      if (za !== aa) return za - aa;
      return z.ratingCount - a.ratingCount;
    })
    .slice(0, limit);
}

export async function getMostCollected(limit = 12): Promise<BookMeta[]> {
  const lib = await getLibrary();
  return [...lib.books.values()]
    .sort((a, z) => popularity(z) - popularity(a))
    .slice(0, limit);
}

export async function getRecentReviews(limit = 8): Promise<ReviewWithMeta[]> {
  const lib = await getLibrary();
  const rows = lib.allLogs
    .filter((l) => l.review && l.rating)
    .sort((a, z) => z.createdAt.getTime() - a.createdAt.getTime())
    .slice(0, limit);
  return rows
    .map((log) => {
      const book = lib.books.get(log.bookId);
      const user = lib.users.get(log.userId);
      if (!book || !user) return null;
      return { log, book, user };
    })
    .filter(Boolean) as ReviewWithMeta[];
}

export async function getBookBySlug(slug: string) {
  const lib = await getLibrary();
  const book = [...lib.books.values()].find((b) => b.slug === slug);
  if (!book) return null;

  const moreByAuthor = [...lib.books.values()]
    .filter((b) => b.authorId === book.authorId && b.id !== book.id)
    .sort((a, z) => popularity(z) - popularity(a))
    .slice(0, 8);

  const alsoEnjoyed = [...lib.books.values()]
    .filter(
      (b) =>
        b.id !== book.id &&
        b.authorId !== book.authorId &&
        b.genres.some((g) => book.genres.includes(g)),
    )
    .map((b) => ({
      b,
      shared: b.genres.filter((g) => book.genres.includes(g)).length,
    }))
    .sort((a, z) => {
      if (z.shared !== a.shared) return z.shared - a.shared;
      return (z.b.avgRating ?? 0) * z.b.ratingCount - (a.b.avgRating ?? 0) * a.b.ratingCount;
    })
    .slice(0, 8)
    .map((x) => x.b);

  const dist = [0, 0, 0, 0, 0]; // 5★..1★ (index 0 = 5 stars w/ rating > 4.5? use buckets)
  const bookLogs = lib.allLogs
    .filter((l) => l.bookId === book.id)
    .sort((a, z) => z.createdAt.getTime() - a.createdAt.getTime());
  for (const l of bookLogs) {
    if (!l.rating) continue;
    const r = parseFloat(l.rating);
    const bucket = Math.max(0, Math.min(4, Math.ceil(r) - 1));
    dist[4 - bucket]++;
  }

  const reviews: ReviewWithMeta[] = bookLogs
    .filter((l) => l.review)
    .slice(0, 24)
    .map((log) => ({ log, book, user: lib.users.get(log.userId)! }))
    .filter((r) => r.user);

  return { book, moreByAuthor, alsoEnjoyed, dist, reviews, bookLogs };
}

export async function getAuthorBySlug(slug: string) {
  const lib = await getLibrary();
  const author = [...lib.authors.values()].find((a) => a.slug === slug);
  if (!author) return null;
  const theirBooks = [...lib.books.values()]
    .filter((b) => b.authorId === author.id)
    .sort((a, z) => popularity(z) - popularity(a));
  const readTotal = theirBooks.reduce((s, b) => s + b.readCount, 0);
  const genres = new Map<string, number>();
  for (const b of theirBooks)
    for (const g of b.genres) genres.set(g, (genres.get(g) ?? 0) + 1);
  const topGenres = [...genres.entries()].sort((a, z) => z[1] - a[1]).slice(0, 4).map(([g]) => g);
  return { author, books: theirBooks, readTotal, topGenres };
}

export type AuthorIndexEntry = Author & {
  bookCount: number;
  readTotal: number;
  topBook: BookMeta | null;
};

export async function getAuthorsIndex(): Promise<AuthorIndexEntry[]> {
  const lib = await getLibrary();
  const byAuthor = new Map<string, BookMeta[]>();
  for (const b of lib.books.values()) {
    const list = byAuthor.get(b.authorId) ?? [];
    list.push(b);
    byAuthor.set(b.authorId, list);
  }
  return [...lib.authors.values()]
    .map((a) => {
      const list = (byAuthor.get(a.id) ?? []).sort(
        (x, z) => popularity(z) - popularity(x),
      );
      return {
        ...a,
        bookCount: list.length,
        readTotal: list.reduce((s, b) => s + b.readCount, 0),
        topBook: list[0] ?? null,
      };
    })
    .sort((a, z) => a.name.localeCompare(z.name));
}

export async function searchLibrary(q: string) {
  const lib = await getLibrary();
  const needle = q.trim().toLowerCase();
  if (!needle) return { books: [] as BookMeta[], authors: [] as AuthorIndexEntry[] };
  const booksHit = [...lib.books.values()]
    .filter(
      (b) =>
        b.title.toLowerCase().includes(needle) ||
        b.author.name.toLowerCase().includes(needle) ||
        b.genres.some((g) => g.toLowerCase() === needle),
    )
    .sort((a, z) => popularity(z) - popularity(a))
    .slice(0, 24);
  const authorsHit = (await getAuthorsIndex())
    .filter((a) => a.name.toLowerCase().includes(needle))
    .slice(0, 8);
  return { books: booksHit, authors: authorsHit };
}

export async function getUserLogs(userId: string) {
  return db
    .select()
    .from(logs)
    .where(eq(logs.userId, userId))
    .orderBy(desc(logs.updatedAt));
}

export async function getUserLogFor(userId: string | undefined, bookId: string) {
  if (!userId) return null;
  const rows = await db
    .select()
    .from(logs)
    .where(and(eq(logs.userId, userId), eq(logs.bookId, bookId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function getBrowseBooks(
  genre: string | undefined,
  sort: string | undefined,
) {
  const lib = await getLibrary();
  let list = [...lib.books.values()];
  if (genre && genre !== "All") {
    list = list.filter((b) => b.genres.includes(genre));
  }
  switch (sort) {
    case "title":
      list.sort((a, z) => a.title.localeCompare(z.title));
      break;
    case "rating":
      list = list.filter((b) => b.ratingCount > 0);
      list.sort((a, z) => (z.avgRating ?? 0) - (a.avgRating ?? 0));
      break;
    case "newest":
      list.sort((a, z) => (z.publishedYear ?? 0) - (a.publishedYear ?? 0));
      break;
    default:
      list.sort((a, z) => popularity(z) - popularity(a));
  }
  return list;
}

export async function getCounts() {
  const [[b], [a], [u], [l]] = await Promise.all([
    db.select({ c: sql<number>`count(*)::int` }).from(books),
    db.select({ c: sql<number>`count(*)::int` }).from(authors),
    db.select({ c: sql<number>`count(*)::int` }).from(users),
    db.select({ c: sql<number>`count(*)::int` }).from(logs).where(isNotNull(logs.rating)),
  ]);
  return { books: b.c, authors: a.c, readers: u.c, ratings: l.c };
}

/* ------------------------------- MOODS ------------------------------- */

export type Mood = {
  id: string;
  label: string;
  tagline: string;
  test: (b: BookMeta) => boolean;
};

export const MOODS: Mood[] = [
  {
    id: "page-turners",
    label: "Page-turners",
    tagline: "Cancel your evening plans.",
    test: (b) => b.genres.some((g) => ["Mystery", "Thriller"].includes(g)) && b.heat >= 7,
  },
  {
    id: "epic-worlds",
    label: "Epic worlds",
    tagline: "Maps, glossaries and doorstoppers.",
    test: (b) =>
      b.genres.some((g) => ["Fantasy", "Sci-Fi"].includes(g)) && (b.pages ?? 0) >= 420,
  },
  {
    id: "short-and-sharp",
    label: "Short & sharp",
    tagline: "Under 230 pages. Hits like a freight train anyway.",
    test: (b) => (b.pages ?? 999) <= 230,
  },
  {
    id: "heartbreakers",
    label: "Heartbreakers",
    tagline: "Love stories that end you politely.",
    test: (b) => b.genres.some((g) => ["Romance", "Literary"].includes(g)) && (b.avgRating ?? 0) >= 3.9,
  },
  {
    id: "after-dark",
    label: "After dark",
    tagline: "Read with the lights on, allegedly.",
    test: (b) => b.genres.some((g) => ["Horror", "Mystery"].includes(g)),
  },
  {
    id: "big-ideas",
    label: "Big ideas",
    tagline: "Essays and arguments to argue with.",
    test: (b) => b.genres.some((g) => ["Nonfiction", "Essays"].includes(g)),
  },
  {
    id: "cry-club",
    label: "Cry club",
    tagline: "Hydrate first. Seriously.",
    test: (b) => b.genres.includes("Memoir") || (b.genres.includes("Literary") && (b.avgRating ?? 0) >= 4.3),
  },
  {
    id: "old-souls",
    label: "Old souls",
    tagline: "The classics, eternally patient.",
    test: (b) => b.genres.includes("Classics"),
  },
];

export function getMoodById(id: string | undefined) {
  return MOODS.find((m) => m.id === id) ?? null;
}

export async function getMoodBooks(mood: Mood, limit = 24): Promise<BookMeta[]> {
  const lib = await getLibrary();
  return [...lib.books.values()]
    .filter((b) => mood.test(b))
    .sort((a, z) => (z.avgRating ?? 0) * Math.log(z.ratingCount + 2) - (a.avgRating ?? 0) * Math.log(a.ratingCount + 2))
    .slice(0, limit);
}

/* ------------------------------ READERS ------------------------------ */

export const getFollowRows = cache(async (): Promise<Follow[]> => {
  return db.select().from(follows);
});

export async function getFollowingIds(viewerId: string): Promise<Set<string>> {
  const rows = await getFollowRows();
  return new Set(rows.filter((f) => f.followerId === viewerId).map((f) => f.followeeId));
}

export async function getFollowerCounts(): Promise<Map<string, number>> {
  const rows = await getFollowRows();
  const m = new Map<string, number>();
  for (const f of rows) m.set(f.followeeId, (m.get(f.followeeId) ?? 0) + 1);
  return m;
}

export type ReaderEntry = User & {
  readCount: number;
  avgRating: number | null;
  reviewCount: number;
  likedCount: number;
  followerCount: number;
  following: boolean;
  topGenre: string | null;
};

export async function getReadersDirectory(viewerId: string | null): Promise<ReaderEntry[]> {
  const [lib, followers, following] = await Promise.all([
    getLibrary(),
    getFollowerCounts(),
    viewerId ? getFollowingIds(viewerId) : Promise.resolve(new Set<string>()),
  ]);

  const out: ReaderEntry[] = [];
  for (const user of lib.users.values()) {
    const theirs = lib.logsByUser.get(user.id) ?? [];
    const rated = theirs.filter((l) => l.rating);
    const genreCount = new Map<string, number>();
    for (const l of theirs) {
      if (l.status !== "read") continue;
      const b = lib.books.get(l.bookId);
      if (!b) continue;
      for (const g of b.genres) genreCount.set(g, (genreCount.get(g) ?? 0) + 1);
    }
    out.push({
      ...user,
      readCount: theirs.filter((l) => l.status === "read").length,
      avgRating: rated.length
          ? rated.reduce((s, l) => s + parseFloat(l.rating!), 0) / rated.length
          : null,
      reviewCount: theirs.filter((l) => l.review).length,
      likedCount: theirs.filter((l) => l.liked).length,
      followerCount: followers.get(user.id) ?? 0,
      following: following.has(user.id),
      topGenre: [...genreCount.entries()].sort((a, z) => z[1] - a[1])[0]?.[0] ?? null,
    });
  }
  return out.sort((a, z) => {
    if (z.readCount !== a.readCount) return z.readCount - a.readCount;
    return z.reviewCount - a.reviewCount;
  });
}

export async function getReaderByUsername(username: string, viewerId: string | null) {
  const dir = await getReadersDirectory(viewerId);
  const reader = dir.find((r) => r.username === username) ?? null;
  if (!reader) return null;
  const lib = await getLibrary();
  const userLogs = lib.logsByUser.get(reader.id) ?? [];
  const withBooks = userLogs
    .map((l) => ({ log: l, book: lib.books.get(l.bookId)! }))
    .filter((x) => x.book);
  return { reader, withBooks, lib };
}

export type FriendActivity = {
  user: User;
  log: Log;
  book: BookMeta;
};

export async function getFriendsActivity(viewerId: string, limit = 9): Promise<FriendActivity[]> {
  const [lib, following] = await Promise.all([getLibrary(), getFollowingIds(viewerId)]);
  if (!following.size) return [];
  const acts: FriendActivity[] = [];
  for (const l of lib.allLogs) {
    if (!following.has(l.userId) || l.status !== "read") continue;
    const book = lib.books.get(l.bookId);
    const user = lib.users.get(l.userId);
    if (!book || !user) continue;
    acts.push({ user, log: l, book });
  }
  return acts
    .sort((a, z) => z.log.createdAt.getTime() - a.log.createdAt.getTime())
    .slice(0, limit);
}

export async function isFollowing(viewerId: string, targetId: string) {
  const following = await getFollowingIds(viewerId);
  return following.has(targetId);
}
