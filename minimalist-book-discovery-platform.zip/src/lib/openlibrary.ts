import { db } from "@/db";
import { authors, books } from "@/db/schema";
import { eq, ilike } from "drizzle-orm";

const OL = "https://openlibrary.org";
const UA = { "User-Agent": "FolioGarden/1.0 (reader community app)" };

/* ------------------------------ types ------------------------------ */

export type OLBookPayload = {
  olKey: string;
  title: string;
  authorName: string;
  authorKey: string | null;
  year: number | null;
  pages: number | null;
  coverUrl: string | null;
  subjects: string[];
  genres: string[];
};

export type OLAuthorHit = {
  key: string;
  name: string;
  topWork: string | null;
  workCount: number;
  photoUrl: string | null;
};

const GENRE_RULES: [RegExp, string][] = [
  [/short stor(y|ies)/i, "Stories"],
  [/science fiction|sci-?fi|dystopi|space opera|time travel/i, "Sci-Fi"],
  [/fantasy|magic|dragon|witch|wizard/i, "Fantasy"],
  [/myster|detectiv|crime|noir|murder/i, "Mystery"],
  [/thriller|suspense|espionage|spy/i, "Thriller"],
  [/horror|ghost|supernatural|gothic/i, "Horror"],
  [/romance|love stor/i, "Romance"],
  [/historical|war fiction|regency|victorian|napoleon/i, "Historical"],
  [/biograph|autobiograph|memoir/i, "Memoir"],
  [/essay|philosoph|literary criticism|criticism/i, "Essays"],
  [/poetr|poems|sonnets/i, "Poetry"],
  [/classic/i, "Classics"],
  [/young adult|juvenile/i, "Literary"],
  [/nonfiction|non-fiction|history|science|psychology|self-?help|politic|econom/i, "Nonfiction"],
  [/fiction|literature|novel/i, "Literary"],
];

export function mapSubjectsToGenres(subjects: string[]): string[] {
  const out: string[] = [];
  for (const [re, genre] of GENRE_RULES) {
    if (subjects.some((s) => re.test(s))) {
      if (!out.includes(genre)) out.push(genre);
      if (out.length >= 3) break;
    }
  }
  return out.length ? out : ["Literary"];
}

async function fetchJson(url: string, timeoutMs = 8000) {
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(timeoutMs),
      headers: { ...UA, Accept: "application/json" },
      cache: "no-store",
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export function slugify(s: string) {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

/* ------------------------------ search ------------------------------ */

export async function searchOpenLibraryBooks(
  q: string,
  limit = 12,
): Promise<OLBookPayload[]> {
  const data = await fetchJson(
    `${OL}/search.json?q=${encodeURIComponent(q)}&language=eng&fields=key,title,author_name,author_key,first_publish_year,number_of_pages_median,cover_i,subject&limit=${limit * 2}`,
  );
  const docs: any[] = data?.docs ?? [];
  const hits = new Map<string, OLBookPayload>();
  for (const d of docs) {
    if (!d?.title || !Array.isArray(d.author_name) || !d.author_name[0]) continue;
    const id = `${d.title}|${d.author_name[0]}`.toLowerCase();
    const subjects: string[] = Array.isArray(d.subject) ? d.subject.slice(0, 40) : [];
    const payload: OLBookPayload = {
      olKey: String(d.key ?? ""),
      title: String(d.title).slice(0, 140),
      authorName: String(d.author_name[0]).slice(0, 80),
      authorKey: Array.isArray(d.author_key) ? String(d.author_key[0]) : null,
      year: typeof d.first_publish_year === "number" ? d.first_publish_year : null,
      pages: typeof d.number_of_pages_median === "number" ? d.number_of_pages_median : null,
      coverUrl:
        typeof d.cover_i === "number"
          ? `https://covers.openlibrary.org/b/id/${d.cover_i}-L.jpg`
          : null,
      subjects,
      genres: mapSubjectsToGenres(subjects),
    };
    const prev = hits.get(id);
    if (!prev || (!prev.coverUrl && payload.coverUrl)) hits.set(id, payload);
    if (hits.size >= limit) break;
  }
  return [...hits.values()];
}

export async function searchOpenLibraryAuthors(
  q: string,
  limit = 4,
): Promise<OLAuthorHit[]> {
  const data = await fetchJson(
    `${OL}/search/authors.json?q=${encodeURIComponent(q)}&limit=${limit}`,
  );
  const docs: any[] = data?.docs ?? [];
  return docs
    .filter((d) => d?.key && d?.name)
    .slice(0, limit)
    .map((d) => ({
      key: String(d.key),
      name: String(d.name),
      topWork: d.top_work ? String(d.top_work) : null,
      workCount: typeof d.work_count === "number" ? d.work_count : 0,
      photoUrl: `https://covers.openlibrary.org/a/olid/${String(d.key)}-L.jpg`,
    }));
}

/* ------------------- author works (for /explore/author) ------------------- */

export type OLAuthorPage = {
  name: string;
  bio: string | null;
  photoUrl: string | null;
  birthDate: string | null;
  works: OLBookPayload[];
};

export async function getOLAuthorPage(key: string): Promise<OLAuthorPage | null> {
  const [doc, worksDoc] = await Promise.all([
    fetchJson(`${OL}/authors/${encodeURIComponent(key)}.json`),
    fetchJson(`${OL}/authors/${encodeURIComponent(key)}/works.json?limit=40`),
  ]);
  if (!doc?.name) return null;
  const bio =
    typeof doc.bio === "string"
      ? doc.bio
      : typeof doc.bio?.value === "string"
        ? doc.bio.value
        : null;
  const entries: any[] = worksDoc?.entries ?? [];
  const works: OLBookPayload[] = [];
  const seen = new Set<string>();
  for (const e of entries) {
    if (!e?.title) continue;
    const id = `${e.title}`.toLowerCase();
    if (seen.has(id)) continue;
    seen.add(id);
    const subjects: string[] = Array.isArray(e.subjects) ? e.subjects.slice(0, 40) : [];
    const yearMatch = typeof e.first_publish_date === "string"
      ? e.first_publish_date.match(/\d{3,4}/)
      : null;
    works.push({
      olKey: String(e.key ?? ""),
      title: String(e.title).slice(0, 140),
      authorName: String(doc.name),
      authorKey: key,
      year: yearMatch ? parseInt(yearMatch[0], 10) : null,
      pages: null,
      coverUrl:
        Array.isArray(e.covers) && typeof e.covers[0] === "number" && e.covers[0] > 0
          ? `https://covers.openlibrary.org/b/id/${e.covers[0]}-L.jpg`
          : null,
      subjects,
      genres: mapSubjectsToGenres(subjects),
    });
    if (works.length >= 24) break;
  }
  // prioritize covered + recent works
  works.sort((a, z) => Number(Boolean(z.coverUrl)) - Number(Boolean(a.coverUrl)));
  return {
    name: String(doc.name),
    bio: bio ? bio.slice(0, 420) : null,
    photoUrl: `https://covers.openlibrary.org/a/olid/${key}-L.jpg`,
    birthDate: typeof doc.birth_date === "string" ? doc.birth_date : null,
    works,
  };
}

/* ------------------------------ import ------------------------------ */

export async function importOLBook(
  p: OLBookPayload,
): Promise<{ bookId: string; slug: string; authorSlug: string }> {
  // find existing book by computed slug
  const slug = slugify(`${p.title}-${p.authorName}`);
  const existing = await db.select().from(books).where(eq(books.slug, slug)).limit(1);
  if (existing[0]) {
    return { bookId: existing[0].id, slug: existing[0].slug, authorSlug: (await getAuthorSlug(existing[0].authorId)) ?? "" };
  }

  // find or create author (case-insensitive name match)
  let author = (
    await db.select().from(authors).where(ilike(authors.name, p.authorName)).limit(1)
  )[0];
  if (!author) {
    author = (
      await db
        .insert(authors)
        .values({
          name: p.authorName,
          slug: await uniqueAuthorSlug(p.authorName),
          bio: "",
          born: "",
          nationality: "",
          photoUrl: p.authorKey ? `https://covers.openlibrary.org/a/olid/${p.authorKey}-L.jpg` : null,
        })
        .returning()
    )[0];
  }

  const description = p.year
    ? `First published in ${p.year}. Catalogued fresh from the Open Library — add a rating and make it ours.`
    : "Catalogued fresh from the Open Library — add a rating and make it ours.";

  const inserted = await db
    .insert(books)
    .values({
      title: p.title,
      slug,
      authorId: author.id,
      description,
      coverUrl: p.coverUrl,
      publishedYear: p.year,
      pages: p.pages,
      genres: p.genres.length ? p.genres : ["Literary"],
      heat: 6,
    })
    .returning();
  return { bookId: inserted[0].id, slug, authorSlug: author.slug };
}

async function getAuthorSlug(authorId: string) {
  const row = (
    await db.select({ slug: authors.slug }).from(authors).where(eq(authors.id, authorId)).limit(1)
  )[0];
  return row?.slug ?? null;
}

async function uniqueAuthorSlug(name: string) {
  const base = slugify(name);
  const clash = await db.select().from(authors).where(eq(authors.slug, base)).limit(1);
  if (!clash[0]) return base;
  return `${base}-${Math.floor(Math.random() * 900 + 100)}`;
}
