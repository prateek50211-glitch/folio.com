import { getLibrary, type BookMeta } from "@/lib/data";
import type { Log } from "@/db/schema";

export type Recommendation = {
  book: BookMeta;
  score: number;
  reason: string;
  seed: BookMeta | null;
};

type Taste = {
  readLogs: Log[];
  loved: Log[]; // rating >= 3.5 or liked
  loggedIds: Set<string>;
  genreScore: Map<string, number>;
  authorScore: Map<string, number>;
};

function buildTaste(userLogs: Log[], books: Map<string, BookMeta>): Taste {
  const readLogs = userLogs.filter((l) => l.status === "read" && l.rating);
  const loved = userLogs.filter(
    (l) => l.status === "read" && (parseFloat(l.rating ?? "0") >= 3.5 || l.liked),
  );
  const genreScore = new Map<string, number>();
  const authorScore = new Map<string, number>();
  for (const l of readLogs) {
    const b = books.get(l.bookId);
    if (!b) continue;
    const r = parseFloat(l.rating ?? "0");
    const delta = Math.max(-1.5, Math.min(2, r - 3.1));
    for (const g of b.genres) {
      genreScore.set(g, (genreScore.get(g) ?? 0) + delta);
    }
    if (r >= 4 || l.liked) {
      authorScore.set(b.authorId, (authorScore.get(b.authorId) ?? 0) + (r - 3));
    }
  }
  return {
    readLogs,
    loved,
    loggedIds: new Set(userLogs.map((l) => l.bookId)),
    genreScore,
    authorScore,
  };
}

function normGenre(gs: number) {
  // squash to roughly -1..1.5
  return Math.tanh(gs / 6) * 1.5;
}

export async function getRecommendations(
  userId: string,
  limit = 12,
): Promise<Recommendation[]> {
  const lib = await getLibrary();
  const userLogs = lib.logsByUser.get(userId) ?? [];
  const taste = buildTaste(userLogs, lib.books);
  if (taste.readLogs.length < 3) return [];

  const lovedBooks = taste.loved
    .map((l) => ({ log: l, book: lib.books.get(l.bookId)! }))
    .filter((x) => x.book)
    .sort(
      (a, z) =>
        (parseFloat(z.log.rating ?? "0") + (z.log.liked ? 0.5 : 0)) -
        (parseFloat(a.log.rating ?? "0") + (a.log.liked ? 0.5 : 0)),
    );

  const bestLovedByAuthor = new Map<string, BookMeta>();
  const bestLovedByGenre = new Map<string, BookMeta>();
  for (const { book } of lovedBooks) {
    if (!bestLovedByAuthor.has(book.authorId))
      bestLovedByAuthor.set(book.authorId, book);
    for (const g of book.genres) {
      if (!bestLovedByGenre.has(g)) bestLovedByGenre.set(g, book);
    }
  }

  const candidates: Recommendation[] = [];
  for (const b of lib.books.values()) {
    if (taste.loggedIds.has(b.id)) continue;

    const gs =
      b.genres.reduce((s, g) => s + normGenre(taste.genreScore.get(g) ?? 0), 0) /
      b.genres.length;
    const as = Math.min(2, taste.authorScore.get(b.authorId) ?? 0);
    const quality = b.avgRating ?? 3.55 + b.heat * 0.03;
    const pop = Math.min(0.7, (b.readCount + b.wantCount) / 60);

    const score = quality * 0.95 + gs * 1.35 + as * 0.9 + pop;
    if (score < 3.35) continue;

    let seed: BookMeta | null = null;
    let reason = "Trending with readers like you";
    const authorSeed = bestLovedByAuthor.get(b.authorId);
    if (authorSeed && authorSeed.id !== b.id) {
      seed = authorSeed;
      reason = `Because you loved “${authorSeed.title}”`;
    } else {
      // best genre among this book's genres
      let best: { g: string; v: number } | null = null;
      for (const g of b.genres) {
        const v = taste.genreScore.get(g) ?? -1;
        if (!best || v > best.v) best = { g, v };
      }
      if (best && best.v > 1.2) {
        const genreSeed = bestLovedByGenre.get(best.g);
        if (genreSeed) {
          seed = genreSeed;
          reason = `Because you loved “${genreSeed.title}”`;
        } else {
          reason = `${best.g} is one of your moods`;
        }
      }
    }
    candidates.push({ book: b, score, reason, seed });
  }

  candidates.sort((a, z) => z.score - a.score);

  // diversify: max 2 per author
  const out: Recommendation[] = [];
  const authorCount = new Map<string, number>();
  for (const c of candidates) {
    const n = authorCount.get(c.book.authorId) ?? 0;
    if (n >= 2) continue;
    authorCount.set(c.book.authorId, n + 1);
    out.push(c);
    if (out.length >= limit) break;
  }
  return out;
}

export type ForYouGroup = {
  seed: BookMeta;
  seedRating: number;
  items: BookMeta[];
};

export async function getForYouGroups(userId: string): Promise<ForYouGroup[]> {
  const lib = await getLibrary();
  const userLogs = lib.logsByUser.get(userId) ?? [];
  const taste = buildTaste(userLogs, lib.books);
  if (taste.readLogs.length < 2) return [];

  const seeds = taste.loved
    .map((l) => ({ log: l, book: lib.books.get(l.bookId)! }))
    .filter((x) => x.book)
    .sort(
      (a, z) => parseFloat(z.log.rating ?? "0") - parseFloat(a.log.rating ?? "0"),
    )
    .slice(0, 8);

  const used = new Set(taste.loggedIds);
  const groups: ForYouGroup[] = [];
  for (const { log, book: seed } of seeds) {
    const seedGenres = new Set(seed.genres);
    const pool = [...lib.books.values()]
      .filter((b) => !used.has(b.id))
      .map((b) => {
        const sharedGenres = b.genres.filter((g) => seedGenres.has(g)).length;
        const sameAuthor = b.authorId === seed.authorId ? 1 : 0;
        const quality = (b.avgRating ?? 3.5) + b.heat * 0.06;
        const score = sameAuthor * 2.2 + sharedGenres * 1.1 + quality * 0.8;
        return { b, score, sameAuthor };
      })
      .filter((x) => x.score > 3)
      .sort((a, z) => z.score - a.score)
      .slice(0, 6);
    if (pool.length < 3) continue;
    const items = pool.map((p) => {
      used.add(p.b.id);
      return p.b;
    });
    groups.push({ seed, seedRating: parseFloat(log.rating ?? "4"), items });
    if (groups.length >= 4) break;
  }
  return groups;
}

export function getTasteProfile(userLogs: Log[], books: Map<string, BookMeta>) {
  const readCount = userLogs.filter((l) => l.status === "read").length;
  const readingCount = userLogs.filter((l) => l.status === "reading").length;
  const wantCount = userLogs.filter((l) => l.status === "want").length;
  const rated = userLogs.filter((l) => l.rating);
  const avgRating = rated.length
    ? rated.reduce((s, l) => s + parseFloat(l.rating!), 0) / rated.length
    : null;
  const genreCount = new Map<string, number>();
  const genreWeighted = new Map<string, { sum: number; n: number }>();
  const authorCount = new Map<string, number>();
  for (const l of userLogs) {
    if (l.status !== "read") continue;
    const b = books.get(l.bookId);
    if (!b) continue;
    authorCount.set(b.authorId, (authorCount.get(b.authorId) ?? 0) + 1);
    for (const g of b.genres) {
      genreCount.set(g, (genreCount.get(g) ?? 0) + 1);
      const r = l.rating ? parseFloat(l.rating) : null;
      if (r) {
        const e = genreWeighted.get(g) ?? { sum: 0, n: 0 };
        e.sum += r;
        e.n++;
        genreWeighted.set(g, e);
      }
    }
  }
  const topGenres = [...genreCount.entries()]
    .sort((a, z) => z[1] - a[1])
    .slice(0, 6)
    .map(([genre, count]) => ({
      genre,
      count,
      avg: (() => {
        const e = genreWeighted.get(genre);
        return e && e.n ? e.sum / e.n : null;
      })(),
    }));
  const topAuthors = [...authorCount.entries()]
    .sort((a, z) => z[1] - a[1])
    .slice(0, 5)
    .map(([authorId, count]) => ({ authorId, count }));
  const reviewCount = userLogs.filter((l) => l.review).length;
  const likedCount = userLogs.filter((l) => l.liked).length;
  const year = new Date().getFullYear();
  const readThisYear = userLogs.filter(
    (l) => l.status === "read" && l.createdAt.getFullYear() === year,
  ).length;
  return {
    readCount,
    readingCount,
    wantCount,
    avgRating,
    topGenres,
    topAuthors,
    reviewCount,
    likedCount,
    readThisYear,
  };
}
