export function cn(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

export function timeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  const intervals: [number, string][] = [
    [60, "second"],
    [60, "minute"],
    [24, "hour"],
    [7, "day"],
    [4.35, "week"],
    [12, "month"],
    [Number.POSITIVE_INFINITY, "year"],
  ];
  let value = seconds;
  let unit = "second";
  let prev = seconds;
  for (let i = 0; i < intervals.length; i++) {
    const [divisor, name] = intervals[i];
    if (value < divisor) {
      unit = name;
      break;
    }
    prev = value;
    value = Math.floor(value / divisor);
    unit = name;
  }
  const v = Math.max(1, Math.floor(value));
  return `${v} ${unit}${v === 1 ? "" : "s"} ago`;
}

export function monthYear(date: Date): string {
  return date.toLocaleDateString("en-US", { month: "long", year: "numeric" });
}

export function hashHue(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h * 31 + s.charCodeAt(i)) >>> 0;
  }
  return h % 360;
}

export function plural(n: number, word: string) {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

export function ratingText(r: number): string {
  if (r >= 4.5) return "Masterpiece";
  if (r >= 4) return "Excellent";
  if (r >= 3.5) return "Great";
  if (r >= 3) return "Good";
  if (r >= 2.5) return "Mixed";
  if (r >= 2) return "Disappointing";
  return "Not for me";
}
