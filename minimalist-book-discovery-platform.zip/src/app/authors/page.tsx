import Link from "next/link";
import type { Metadata } from "next";
import { getAuthorsIndex } from "@/lib/data";
import { AuthorPortrait } from "@/components/AuthorPortrait";

export const metadata: Metadata = { title: "Authors" };

export default async function AuthorsPage() {
  const authors = await getAuthorsIndex();

  const groups = new Map<string, typeof authors>();
  for (const a of authors) {
    const surname = a.name.trim().split(/\s+/).slice(-1)[0];
    const letter = surname[0]?.toUpperCase() ?? "#";
    const list = groups.get(letter) ?? [];
    list.push(a);
    groups.set(letter, list);
  }
  const letters = [...groups.keys()].sort();

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <header className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="kicker text-rust">The writing life</p>
          <h1 className="display mt-3 text-5xl leading-none sm:text-6xl">
            Every voice in the room.
          </h1>
        </div>
        <p className="mb-1 text-sm text-ink-2">
          <span className="display text-2xl text-ink">{authors.length}</span> authors
        </p>
      </header>

      <div className="mt-12 space-y-12">
        {letters.map((letter) => (
          <section key={letter}>
            <div className="flex items-baseline gap-4 border-b border-ink/15 pb-3">
              <p className="display text-3xl text-rust">{letter}</p>
              <p className="kicker text-ink-3">
                {groups.get(letter)!.length}{" "}
                {groups.get(letter)!.length === 1 ? "author" : "authors"}
              </p>
            </div>
            <div>
              {groups.get(letter)!.map((a) => (
                <Link
                  key={a.id}
                  href={`/authors/${a.slug}`}
                  className="group flex items-center gap-5 border-b border-ink/5 py-4 transition-colors hover:bg-paper-2/50"
                >
                  <div className="h-14 w-11 shrink-0">
                    <AuthorPortrait
                      name={a.name}
                      src={a.photoUrl}
                      className="h-full w-full"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="display text-xl leading-tight transition-colors group-hover:text-rust sm:text-2xl">
                      {a.name}
                    </p>
                    <p className="mt-1 truncate text-xs text-ink-2">
                      {a.nationality}
                      {a.born ? ` · ${a.born}` : ""}
                    </p>
                  </div>
                  {a.topBook && (
                    <p className="hidden max-w-[220px] truncate text-sm italic text-ink-3 md:block">
                      “{a.topBook.title}”
                    </p>
                  )}
                  <div className="ml-auto shrink-0 text-right">
                    <p className="display text-lg leading-none">{a.bookCount}</p>
                    <p className="kicker mt-1 text-ink-3">
                      {a.bookCount === 1 ? "book" : "books"}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
