import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getAuthorBySlug, getAuthorsIndex, popularity } from "@/lib/data";
import { BookGrid } from "@/components/BookCard";
import { SectionHead } from "@/components/SectionHead";
import { AuthorPortrait } from "@/components/AuthorPortrait";
import { AuthorCard } from "@/components/AuthorCard";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const data = await getAuthorBySlug(slug);
  return { title: data ? data.author.name : "Author" };
}

export default async function AuthorPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const data = await getAuthorBySlug(slug);
  if (!data) notFound();
  const { author, books, readTotal, topGenres } = data;

  // kindred voices: authors sharing the top genre
  const allAuthors = await getAuthorsIndex();
  const genreSet = new Set(topGenres);
  const kindred = allAuthors
    .filter((a) => a.id !== author.id)
    .map((a) => {
      const shared = (a.topBook?.genres ?? []).filter((g) => genreSet.has(g)).length;
      return { a, shared };
    })
    .sort((x, z) => z.shared - x.shared || z.a.readTotal - x.a.readTotal)
    .slice(0, 4)
    .map((x) => x.a);

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <p className="kicker mb-10 text-ink-3">
        <Link href="/authors" className="transition-colors hover:text-rust">
          Authors
        </Link>
        <span className="mx-2 text-ink/25">/</span>
        {author.name}
      </p>

      {/* HERO */}
      <header className="grid gap-10 md:grid-cols-[1fr_240px] lg:grid-cols-[1fr_280px] lg:gap-16">
        <div>
          <p className="kicker text-rust">
            {author.nationality}
            {author.born ? ` · ${author.born}` : ""}
          </p>
          <h1 className="display display-tight mt-4 text-[clamp(2.8rem,7vw,5.5rem)] leading-[0.95]">
            {author.name}
          </h1>
          {author.bio && (
            <p className="display mt-7 max-w-xl text-xl leading-relaxed text-ink-2">
              {author.bio}
            </p>
          )}
          <div className="mt-8 flex flex-wrap gap-2.5">
            {topGenres.map((g) => (
              <Link
                key={g}
                href={`/books?genre=${encodeURIComponent(g)}`}
                className="rounded-full border border-ink/15 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-2 transition-colors hover:border-ink hover:text-ink"
              >
                {g}
              </Link>
            ))}
          </div>
          <div className="mt-9 flex gap-10 border-t border-ink/10 pt-6">
            {[
              { n: books.length, label: books.length === 1 ? "Book" : "Books" },
              { n: readTotal, label: "Reads logged" },
            ].map((s) => (
              <div key={s.label}>
                <p className="display text-4xl leading-none">{s.n}</p>
                <p className="kicker mt-2 text-ink-3">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
        <div className="mx-auto w-full max-w-[240px] md:mx-0">
          <AuthorPortrait
            name={author.name}
            src={author.photoUrl}
            className="aspect-[3/4] w-full shadow-[0_20px_40px_-20px_rgba(23,19,13,0.45)]"
          />
          <p className="kicker mt-3 text-center text-ink-3">Portrait · Wikimedia</p>
        </div>
      </header>

      {/* WORKS */}
      <section className="mt-16">
        <SectionHead
          index="01"
          sub="The works"
          title={`Every book by ${author.name.split(" ").slice(-1)[0]}`}
        />
        <BookGrid books={books.map((b) => ({ book: b }))} />
      </section>

      {/* KINDRED */}
      {kindred.length > 0 && (
        <section className="mt-16">
          <SectionHead
            index="02"
            sub="Kindred voices"
            title="If the pen continues"
            href="/authors"
            hrefLabel="All authors"
          />
          <div className="grid grid-cols-2 gap-6 sm:grid-cols-4">
            {kindred.map((a) => (
              <AuthorCard key={a.id} author={a} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
