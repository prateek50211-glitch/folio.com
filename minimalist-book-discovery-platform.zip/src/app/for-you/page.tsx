import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getLibrary, getUserLogs } from "@/lib/data";
import { getForYouGroups, getRecommendations, getTasteProfile } from "@/lib/recs";
import { BookCard, BookGrid, BookRail } from "@/components/BookCard";
import { RatingStars } from "@/components/RatingStars";
import { SectionHead } from "@/components/SectionHead";
import { Compass, Sparkles } from "lucide-react";

export const metadata: Metadata = { title: "For You" };
export const dynamic = "force-dynamic";

export default async function ForYouPage() {
  const user = await getSessionUser();
  if (!user) redirect("/sign-in");

  const [recs, groups, lib, userLogs] = await Promise.all([
    getRecommendations(user.id, 18),
    getForYouGroups(user.id),
    getLibrary(),
    getUserLogs(user.id),
  ]);

  const taste = getTasteProfile(userLogs, lib.books);
  const loggedIds = new Set(userLogs.map((l) => l.bookId));
  const triedGenres = new Set(taste.topGenres.map((g) => g.genre));

  const untouched = [...lib.books.values()]
    .filter(
      (b) =>
        !loggedIds.has(b.id) &&
        !b.genres.some((g) => triedGenres.has(g)) &&
        b.ratingCount >= 2,
    )
    .sort((a, z) => (z.avgRating ?? 0) - (a.avgRating ?? 0))
    .slice(0, 8);

  const firstName = user.displayName.split(" ")[0];

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <header className="max-w-2xl">
        <p className="kicker flex items-center gap-2 text-rust">
          <Sparkles size={13} /> Recommendation engine
        </p>
        <h1 className="display mt-4 text-5xl leading-[1.0] sm:text-6xl">
          Shelves chosen
          <br />
          <em className="text-ink-2">for {firstName}.</em>
        </h1>
        <p className="mt-5 text-base leading-relaxed text-ink-2">
          Woven from {taste.readCount} logged {taste.readCount === 1 ? "book" : "books"}
          {taste.topGenres[0] ? (
            <>
              {" "}— heavy on{" "}
              {taste.topGenres.slice(0, 2).map((g) => g.genre.toLowerCase()).join(" and ")}
            </>
          ) : null}
          . It gets sharper with every star you give.
        </p>
      </header>

      {recs.length === 0 && groups.length === 0 ? (
        <div className="mt-12 rounded-lg border border-dashed border-ink/25 bg-paper-2/40 p-10">
          <Compass size={22} className="text-rust" strokeWidth={1.5} />
          <h2 className="display mt-4 text-3xl">The compass needs three stars.</h2>
          <p className="mt-3 max-w-lg text-sm leading-relaxed text-ink-2">
            Log and rate at least three books and this page blooms. Until then,
            the <Link href="/books" className="u-sweep text-rust">stacks</Link> are a
            lovely place to wander.
          </p>
        </div>
      ) : (
        <>
          {recs.length > 0 && (
            <section className="mt-12">
              <SectionHead
                index="01"
                sub="Your shortlist"
                title="The next twelve"
              />
              <BookGrid
                reasons
                books={recs.map((r) => ({ book: r.book, reason: r.reason }))}
              />
            </section>
          )}

          {groups.map((g, i) => (
            <section key={g.seed.id} className="mt-14">
              <SectionHead
                index={String(recs.length > 0 ? i + 2 : i + 1).padStart(2, "0")}
                sub="A reason to return"
                title={`Because you loved “${g.seed.title}”`}
                href={`/books/${g.seed.slug}`}
                hrefLabel="Revisit"
              />
              <div className="mb-5 flex items-center gap-3">
                <p className="text-sm text-ink-2">Your rating:</p>
                <RatingStars rating={g.seedRating} size={13} />
              </div>
              <BookRail books={g.items.map((b) => ({ book: b }))} />
            </section>
          ))}

          {untouched.length > 0 && (
            <section className="mt-14">
              <SectionHead
                index="—"
                sub="Untouched country"
                title="Genres you haven’t tried yet"
              />
              <p className="mb-6 max-w-xl text-sm leading-relaxed text-ink-2">
                Sometimes the best recommendation is a left turn. Highly loved
                books from shelves you rarely visit.
              </p>
              <div className="no-scrollbar -mx-5 flex snap-x gap-5 overflow-x-auto px-5 pb-2 sm:-mx-8 sm:px-8">
                {untouched.map((b) => (
                  <div key={b.id} className="w-[132px] shrink-0 snap-start sm:w-[148px]">
                    <BookCard book={b} reason={b.genres[0]} />
                  </div>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
