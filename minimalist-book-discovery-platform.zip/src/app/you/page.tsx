import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getLibrary, getUserLogs, type BookMeta } from "@/lib/data";
import { getTasteProfile } from "@/lib/recs";
import { BookCover } from "@/components/BookCover";
import { Avatar } from "@/components/Avatar";
import { RatingStars } from "@/components/RatingStars";
import { SectionHead } from "@/components/SectionHead";
import { BookGrid } from "@/components/BookCard";
import { Heart } from "lucide-react";
import { monthYear, plural } from "@/lib/utils";

export const metadata: Metadata = { title: "Your diary" };
export const dynamic = "force-dynamic";

export default async function YouPage() {
  const user = await getSessionUser();
  if (!user) redirect("/sign-in");

  const [lib, userLogs] = await Promise.all([getLibrary(), getUserLogs(user.id)]);
  const taste = getTasteProfile(userLogs, lib.books);

  const withBooks = userLogs
    .map((l) => ({ log: l, book: lib.books.get(l.bookId)! }))
    .filter((x) => x.book);

  const activity = withBooks.filter((x) => x.log.status === "read").slice(0, 12);
  const reading = withBooks.filter((x) => x.log.status === "reading");
  const want = withBooks.filter((x) => x.log.status === "want");
  const reviews = withBooks.filter((x) => x.log.review);
  const maxGenre = Math.max(1, ...taste.topGenres.map((g) => g.count));

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      {/* HEADER */}
      <header className="flex flex-col gap-8 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-5">
          <Avatar name={user.displayName} className="h-16 w-16 text-2xl" />
          <div>
            <h1 className="display text-4xl leading-none sm:text-5xl">
              {user.displayName}
            </h1>
            <p className="mt-2 text-sm text-ink-2">
              @{user.username} · reading since {monthYear(user.createdAt)}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-6 sm:gap-8">
          {[
            { n: taste.readCount, label: "Read" },
            { n: taste.readingCount, label: "Reading" },
            { n: taste.wantCount, label: "Want" },
            { n: taste.reviewCount, label: "Reviews" },
            { n: taste.likedCount, label: "Loved" },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <p className="display text-3xl leading-none">{s.n}</p>
              <p className="kicker mt-1.5 text-ink-3">{s.label}</p>
            </div>
          ))}
        </div>
      </header>

      {/* TASTE */}
      {taste.topGenres.length > 0 && (
        <section className="mt-12 grid gap-10 md:grid-cols-2">
          <div className="border-t border-ink/15 pt-5">
            <p className="kicker mb-5 text-rust">Your taste, in bars</p>
            <div className="space-y-3.5">
              {taste.topGenres.map((g) => (
                <div key={g.genre}>
                  <div className="mb-1 flex items-baseline justify-between text-sm">
                    <Link
                      href={`/books?genre=${encodeURIComponent(g.genre)}`}
                      className="font-medium transition-colors hover:text-rust"
                    >
                      {g.genre}
                    </Link>
                    <span className="text-xs text-ink-3">
                      {plural(g.count, "book")}
                      {g.avg ? ` · ${g.avg.toFixed(1)}★ avg` : ""}
                    </span>
                  </div>
                  <div className="h-[6px] overflow-hidden rounded-full bg-paper-3">
                    <div
                      className="h-full rounded-full bg-rust/80"
                      style={{ width: `${(g.count / maxGenre) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="border-t border-ink/15 pt-5">
            <p className="kicker mb-5 text-rust">Handed down verdict</p>
            <div className="flex h-full flex-col justify-between gap-6">
              <p className="display text-[clamp(1.5rem,3vw,2.1rem)] leading-tight">
                {makeVerdict(taste.avgRating, taste.topGenres[0]?.genre)}
              </p>
              {taste.avgRating && (
                <div className="flex items-center gap-3">
                  <RatingStars rating={taste.avgRating} size={15} />
                  <span className="display text-2xl">{taste.avgRating.toFixed(2)}</span>
                  <span className="text-xs text-ink-3">your lifetime average</span>
                </div>
              )}
            </div>
          </div>
        </section>
      )}

      {/* READING */}
      {reading.length > 0 && (
        <section className="mt-14">
          <SectionHead index="01" sub="In progress" title="Currently reading" />
          <BookGrid
            books={reading.map(({ book }) => ({ book, reason: "In progress" }))}
            reasons
          />
        </section>
      )}

      {/* ACTIVITY */}
      <section className="mt-14">
        <SectionHead index="02" sub="Diary" title="Recent reading" />
        {activity.length === 0 ? (
          <p className="border-t border-ink/10 py-10 text-sm italic text-ink-3">
            Nothing logged yet. Open a <Link href="/books" className="u-sweep text-rust">book page</Link> and press “Log”.
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-x-4 gap-y-8 sm:grid-cols-4 md:grid-cols-6">
            {activity.map(({ log, book }) => (
              <Link key={log.id} href={`/books/${book.slug}`} className="group">
                <div className="lift">
                  <BookCover title={book.title} author={book.author.name} src={book.coverUrl} />
                </div>
                <div className="mt-2.5 flex items-center gap-1.5">
                  {log.rating ? (
                    <RatingStars rating={parseFloat(log.rating)} size={10} gap={1.5} />
                  ) : (
                    <span className="text-[11px] italic text-ink-3">unrated</span>
                  )}
                  {log.liked && <Heart size={10} className="text-rust" fill="currentColor" />}
                </div>
                <p className="mt-1 text-[11px] uppercase tracking-[0.12em] text-ink-3">
                  {monthYear(log.createdAt)}
                </p>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* WANT */}
      <section id="want" className="mt-14 scroll-mt-24">
        <SectionHead index="03" sub="The pile" title="Want to read" />
        {want.length === 0 ? (
          <p className="border-t border-ink/10 py-10 text-sm italic text-ink-3">
            An empty wishlist is a kind of optimism too.
          </p>
        ) : (
          <BookGrid books={want.map(({ book }) => ({ book }))} />
        )}
      </section>

      {/* REVIEWS */}
      <section id="reviews" className="mt-14 scroll-mt-24">
        <SectionHead index="04" sub="Marginalia" title="Your notes" />
        {reviews.length === 0 ? (
          <p className="border-t border-ink/10 py-10 text-sm italic text-ink-3">
            No notes yet. The best ones are written at 1 a.m., slightly angry.
          </p>
        ) : (
          <div className="divide-y divide-ink/10 border-y border-ink/10">
            {reviews.map(({ log, book }) => (
              <div key={log.id} className="grid gap-4 py-6 sm:grid-cols-[64px_1fr]">
                <Link href={`/books/${book.slug}`} className="block w-16 shrink-0">
                  <BookCover title={book.title} author={book.author.name} src={book.coverUrl} />
                </Link>
                <div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <Link
                      href={`/books/${book.slug}`}
                      className="display text-lg transition-colors hover:text-rust"
                    >
                      {book.title}
                    </Link>
                    {log.rating && <RatingStars rating={parseFloat(log.rating)} size={11} gap={1.5} />}
                    <span className="text-[11px] uppercase tracking-[0.12em] text-ink-3">
                      {monthYear(log.createdAt)}
                    </span>
                  </div>
                  <p className="mt-2 max-w-3xl text-[15px] leading-relaxed text-ink/90">
                    {log.review}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function makeVerdict(avg: number | null, topGenre?: string) {
  if (!avg) return "Your shelf is young; its legend is unwritten.";
  const genreBit = topGenre ? `${topGenre.toLowerCase()} at heart` : "eclectic at heart";
  if (avg >= 4.2) return `A generous reader — ${genreBit}, and easy to delight.`;
  if (avg >= 3.7) return `A fair mind — ${genreBit}, sparing with the fifth star.`;
  if (avg >= 3.1) return `A critic's eye — ${genreBit}, and hard won over.`;
  return `Merciless and magnificent — ${genreBit}, allergic to hype.`;
}
