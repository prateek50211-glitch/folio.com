"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { follows, logs, users, type LogStatus } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import {
  SESSION_COOKIE,
  createSessionToken,
  destroySessionToken,
  getSessionUser,
} from "@/lib/auth";
import { importOLBook, type OLBookPayload } from "@/lib/openlibrary";

function normalizeUsername(raw: string) {
  return raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_]+/g, "")
    .slice(0, 24);
}

export async function signInAction(formData: FormData) {
  const name = String(formData.get("username") ?? "");
  const username = normalizeUsername(name);
  if (username.length < 2) {
    redirect("/sign-in?error=short");
  }
  let user = (
    await db.select().from(users).where(eq(users.username, username)).limit(1)
  )[0];
  if (!user) {
    const displayName =
      name.trim().replace(/\s+/g, " ").slice(0, 40) || username;
    user = (
      await db
        .insert(users)
        .values({ username, displayName })
        .returning()
    )[0];
  }
  const { token, expiresAt } = await createSessionToken(user.id);
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    expires: expiresAt,
    path: "/",
  });
  redirect("/");
}

export async function signOutAction() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await destroySessionToken(token);
  store.delete(SESSION_COOKIE);
  redirect("/");
}

type SaveLogInput = {
  bookId: string;
  status: LogStatus;
  rating: number | null;
  liked: boolean;
  review: string | null;
};

export async function saveLogAction(input: SaveLogInput) {
  const user = await getSessionUser();
  if (!user) return { ok: false, error: "signin" } as const;

  const rating =
    input.status === "read" && input.rating && input.rating >= 0.5
      ? Math.min(5, Math.round(input.rating * 2) / 2).toFixed(1)
      : null;
  const review = input.review?.trim() ? input.review.trim().slice(0, 2000) : null;

  await db
    .insert(logs)
    .values({
      userId: user.id,
      bookId: input.bookId,
      status: input.status,
      rating,
      liked: input.liked,
      review,
    })
    .onConflictDoUpdate({
      target: [logs.userId, logs.bookId],
      set: {
        status: input.status,
        rating,
        liked: input.liked,
        review,
        updatedAt: new Date(),
      },
    });

  revalidatePath("/", "layout");
  return { ok: true } as const;
}

export async function removeLogAction(bookId: string) {
  const user = await getSessionUser();
  if (!user) return { ok: false, error: "signin" } as const;
  await db
    .delete(logs)
    .where(and(eq(logs.userId, user.id), eq(logs.bookId, bookId)));
  revalidatePath("/", "layout");
  return { ok: true } as const;
}

export async function quickStatusAction(bookId: string, status: LogStatus) {
  const user = await getSessionUser();
  if (!user) return { ok: false, error: "signin" } as const;
  const existing = (
    await db
      .select()
      .from(logs)
      .where(and(eq(logs.userId, user.id), eq(logs.bookId, bookId)))
      .limit(1)
  )[0];
  if (existing && existing.status === status) {
    await db
      .delete(logs)
      .where(and(eq(logs.userId, user.id), eq(logs.bookId, bookId)));
  } else if (existing) {
    await db
      .update(logs)
      .set({ status, updatedAt: new Date() })
      .where(and(eq(logs.userId, user.id), eq(logs.bookId, bookId)));
  } else {
    await db.insert(logs).values({ userId: user.id, bookId, status });
  }
  revalidatePath("/", "layout");
  return { ok: true } as const;
}

/* ---------- Open Library: inscribe (import + shelf in one click) ---------- */

export async function inscribeFromOLAction(payload: OLBookPayload, status: LogStatus = "want") {
  const user = await getSessionUser();
  if (!user) return { ok: false, error: "signin" } as const;
  try {
    const { bookId, slug } = await importOLBook(payload);
    const existing = (
      await db
        .select()
        .from(logs)
        .where(and(eq(logs.userId, user.id), eq(logs.bookId, bookId)))
        .limit(1)
    )[0];
    if (existing) {
      await db
        .update(logs)
        .set({ status, updatedAt: new Date() })
        .where(and(eq(logs.userId, user.id), eq(logs.bookId, bookId)));
    } else {
      await db.insert(logs).values({ userId: user.id, bookId, status });
    }
    revalidatePath("/", "layout");
    return { ok: true, slug } as const;
  } catch {
    return { ok: false, error: "import" } as const;
  }
}

export async function openOLBookAction(payload: OLBookPayload) {
  const user = await getSessionUser();
  if (!user) return { ok: false, error: "signin" } as const;
  try {
    const { slug } = await importOLBook(payload);
    revalidatePath("/", "layout");
    return { ok: true, slug } as const;
  } catch {
    return { ok: false, error: "import" } as const;
  }
}

/* ------------------------------ follows ------------------------------ */

export async function followAction(username: string) {
  const user = await getSessionUser();
  if (!user) return { ok: false, error: "signin" } as const;
  const target = (
    await db.select().from(users).where(eq(users.username, username)).limit(1)
  )[0];
  if (!target || target.id === user.id) return { ok: false, error: "invalid" } as const;

  const existing = (
    await db
      .select()
      .from(follows)
      .where(and(eq(follows.followerId, user.id), eq(follows.followeeId, target.id)))
      .limit(1)
  )[0];
  let following: boolean;
  if (existing) {
    await db
      .delete(follows)
      .where(and(eq(follows.followerId, user.id), eq(follows.followeeId, target.id)));
    following = false;
  } else {
    await db.insert(follows).values({ followerId: user.id, followeeId: target.id });
    following = true;
  }
  revalidatePath("/", "layout");
  return { ok: true, following } as const;
}
