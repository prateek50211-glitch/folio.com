import Link from "next/link";
import type { User } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import {
  getCounts,
  getFriendsActivity,
  getMostCollected,
  getPopularThisWeek,
  getRecentReviews,
  getAuthorsIndex,
  getLibrary,
  type BookMeta,
} from "@/lib/data";
import { getRecommendations, getTasteProfile } from "@/lib/recs";
import { FriendActivityCard } from "@/components/FriendActivity";
import { getUserLogs } from "@/lib/data";
import { BookCard, BookGrid, BookRail } from "@/components/BookCard";
import { BookCover } from "@/components/BookCover";
import { ReviewTeaser } from "@/components/ReviewCard";
import { SectionHead } from "@/components/SectionHead";
import { MarqueeCovers } from "@/components/MarqueeCovers";
import { AuthorCard } from "@/components/AuthorCard";
import { ArrowUpRight, BookOpen, Library, Sparkles, Star } from "lucide-react";

export default async function Home() {
  const user = await getSessionUser();
  return user ? <AuthedHome user={user} /> : <Landing />;
}

/* ------------------------------ LANDING ------------------------------ */

async function Landing() {
  const [collected, reviews, counts, authorsIdx] = await Promise.all([
    getMostCollected(28),
    getRecentReviews(3),
    getCounts(),
    getAuthorsIndex(),
  ]);
  const fan = collected.slice(0, 5);
  const marqueeTop = collected.slice(5, 19);
  const marqueeBottom = collected.slice(14, 28);
  const featuredAuthors = [...authorsIdx]
    .sort((a, z) => z.readTotal - a.readTotal)
    .slice(0, 4);

  return (
    <div>
      {/* HERO */}
      <section className="mx-auto max-w-[1240px] px-5 pb-10 pt-14 sm:px-8 sm:pt-20">
        <div className="grid items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
          <div>
            <p className="kicker flex items-center gap-2 text-rust">
              <span className="h-px w-8 bg-rust" />
              A home for readers
            </p>
            <h1 className="display mt-5 text-[clamp(3rem,7.5vw,5.6rem)] leading-[0.98]">
              Keep every story
              <br />
              <em className="text-rust">you’ve ever met.</em>
            </h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-ink-2">
              Log the books you’ve read, rate the ones that wrecked you, and let
              Folio quietly find your next great love.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                href="/sign-in"
                className="group inline-flex items-center gap-2 rounded-full bg-ink px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-paper transition-colors hover:bg-rust"
              >
                Start your shelf
                <ArrowUpRight
                  size={14}
                  className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                />
              </Link>
              <Link
                href="/books"
                className="inline-flex items-center gap-2 rounded-full border border-ink/25 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.18em] transition-colors hover:border-ink hover:bg-paper-2"
              >
                Browse the stacks
              </Link>
            </div>
          </div>
          <div className="relative mx-auto hidden h-[430px] w-full max-w-[520px] sm:block">
            {fan.map((b, i) => (
              <div
                key={b.id}
                className="lift absolute w-[168px]"
                style={{
                  left: `${4 + i * 17}%`,
                  top: `${(i % 2) * 34 + 6}px`,
                  transform: `rotate(${(i - 2) * 5.5}deg)`,
                  zIndex: 10 - Math.abs(i - 2),
                }}
              >
                <BookCover
                  title={b.title}
                  author={b.author.name}
                  src={b.coverUrl}
                  eager
                />
                <p className="mt-2 text-center text-[11px] text-ink-2">
                  {b.title}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <MarqueeCovers top={marqueeTop} bottom={marqueeBottom} />

      {/* NUMBERS */}
      <section className="mx-auto max-w-[1240px] px-5 py-14 sm:px-8">
        <div className="grid grid-cols-2 gap-y-8 border-y border-ink/15 py-8 md:grid-cols-4">
          {[
            { n: counts.books, label: "Books catalogued" },
            { n: counts.authors, label: "Authors profiled" },
            { n: counts.ratings, label: "Ratings cast" },
            { n: counts.readers, label: "Readers in the room" },
          ].map((s) => (
            <div key={s.label} className="text-center">
              <p className="display text-4xl sm:text-5xl">
                {s.n.toLocaleString()}
              </p>
              <p className="kicker mt-2 text-ink-3">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="mx-auto max-w-[1240px] px-5 py-10 sm:px-8">
        <div className="grid gap-10 md:grid-cols-3">
          {[
            {
              no: "01",
              icon: Library,
              title: "Log the books",
              copy: "One tap shelves a book as read, reading or want-to-read. Your diary builds itself.",
            },
            {
              no: "02",
              icon: Star,
              title: "Rate what it did to you",
              copy: "Half-star precision, hearts for the ones that rearranged your furniture, reviews when words come.",
            },
            {
              no: "03",
              icon: Sparkles,
              title: "Follow your taste",
              copy: "Folio reads your reading — and recommends with eerily good judgment. No ads, no noise.",
            },
          ].map((f) => (
            <div key={f.no} className="border-t border-ink/15 pt-5">
              <div className="flex items-baseline justify-between">
                <p className="display text-5xl text-ink-3/60">{f.no}</p>
                <f.icon size={20} className="text-rust" strokeWidth={1.6} />
              </div>
              <h3 className="display mt-4 text-2xl">{f.title}</h3>
              <p className="mt-2 max-w-xs text-sm leading-relaxed text-ink-2">
                {f.copy}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* REVIEWS */}
      <section className="mx-auto max-w-[1240px] px-5 py-14 sm:px-8">
        <SectionHead index="01" sub="Marginalia" title="Fresh from the community" href="/books" hrefLabel="Browse books" />
        <div className="grid gap-8 md:grid-cols-3">
          {reviews.map((r) => (
            <ReviewTeaser key={r.log.id} review={r} />
          ))}
        </div>
      </section>

      {/* AUTHORS */}
      <section className="mx-auto max-w-[1240px] px-5 py-14 sm:px-8">
        <SectionHead index="02" sub="The writing life" title="Follow the voices" href="/authors" hrefLabel="All authors" />
        <div className="grid grid-cols-2 gap-6 sm:grid-cols-4">
          {featuredAuthors.map((a) => (
            <AuthorCard key={a.id} author={a} />
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-[1240px] px-5 py-16 sm:px-8">
        <div className="rounded-lg bg-ink px-6 py-14 text-center text-paper sm:py-20">
          <BookOpen size={22} className="mx-auto text-rust" strokeWidth={1.5} />
          <h2 className="display mx-auto mt-6 max-w-3xl text-[clamp(1.9rem,4.5vw,3.4rem)] leading-[1.05]">
            Your next favorite book is already looking for you.
          </h2>
          <p className="mx-auto mt-5 max-w-md text-sm leading-relaxed text-paper/60">
            Join the reading room. It takes a name and about twenty seconds.
          </p>
          <Link
            href="/sign-in"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-paper px-8 py-4 text-xs font-semibold uppercase tracking-[0.18em] text-ink transition-colors hover:bg-rust hover:text-paper"
          >
            Start your shelf
          </Link>
        </div>
      </section>
    </div>
  );
}

/* ---------------------------- SIGNED-IN HOME ---------------------------- */

async function AuthedHome({ user }: { user: User }) {
  const userId = user.id;
  const [userLogs, recs, popular, reviews, lib, friendActs] = await Promise.all([
    getUserLogs(userId),
    getRecommendations(userId, 12),
    getPopularThisWeek(12),
    getRecentReviews(5),
    getLibrary(),
    getFriendsActivity(userId, 9),
  ]);

  const taste = getTasteProfile(userLogs, lib.books);
  const loggedIds = new Set(userLogs.map((l) => l.bookId));
  const reading = userLogs
    .filter((l) => l.status === "reading")
    .slice(0, 10)
    .map((l) => lib.books.get(l.bookId)!)
    .filter(Boolean);

  // favorite author with unread books
  const favAuthorId = taste.topAuthors[0]?.authorId;
  const moreByFav: BookMeta[] = favAuthorId
    ? [...lib.books.values()]
        .filter((b) => b.authorId === favAuthorId && !loggedIds.has(b.id))
        .slice(0, 8)
    : [];
  const favAuthor = favAuthorId ? lib.authors.get(favAuthorId) : null;

  const hour = new Date().getHours();
  const greet =
    hour < 5 ? "Still up" : hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const firstName = user.displayName.split(" ")[0];
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="mx-auto max-w-[1240px] px-5 sm:px-8">
      {/* Greeting */}
      <section className="pb-10 pt-12 sm:pt-16">
        <p className="kicker text-rust">{today}</p>
        <h1 className="display mt-3 text-[clamp(2.4rem,6vw,4.4rem)] leading-[1.0]">
          {greet}, {firstName}.
          <br />
          <em className="text-ink-2">What are we reading tonight?</em>
        </h1>
        <div className="mt-7 flex flex-wrap gap-2.5">
          {[
            { n: taste.readThisYear, label: "read this year" },
            { n: taste.readingCount, label: "in progress" },
            { n: taste.wantCount, label: "on the shelf" },
            {
              n: taste.avgRating ? taste.avgRating.toFixed(1) : "—",
              label: "your average rating",
            },
          ].map((s) => (
            <span
              key={s.label}
              className="rounded-full border border-ink/15 bg-paper-2/50 px-4 py-2 text-xs text-ink-2"
            >
              <span className="display mr-1.5 text-base text-ink">{s.n}</span>
              {s.label}
            </span>
          ))}
        </div>
      </section>

      {taste.readCount === 0 ? (
        <Onboarding popular={popular} />
      ) : (
        <>
          {reading.length > 0 && (
            <section className="pb-12">
              <SectionHead
                index="01"
                sub="In progress"
                title="On your nightstand"
                href="/you"
                hrefLabel="Your diary"
              />
              <BookRail
                books={reading.map((b) => ({ book: b, reason: "Currently reading" }))}
                reasons
              />
            </section>
          )}

          {recs.length > 0 && (
            <section className="pb-12">
              <SectionHead
                index={reading.length > 0 ? "02" : "01"}
                sub="Recommended"
                title="Chosen for you"
                href="/for-you"
                hrefLabel="More like this"
              />
              <BookRail
                books={recs.map((r) => ({ book: r.book, reason: r.reason }))}
                reasons
              />
            </section>
          )}

          {moreByFav.length > 0 && favAuthor && (
            <section className="pb-12">
              <SectionHead
                index="03"
                sub="A familiar voice"
                title={`More by ${favAuthor.name}`}
                href={`/authors/${favAuthor.slug}`}
                hrefLabel="Author page"
              />
              <BookRail books={moreByFav.map((b) => ({ book: b }))} />
            </section>
          )}
        </>
      )}

      <section className="pb-12">
        <SectionHead
          index="04"
          sub="The zeitgeist"
          title="Read this week"
          href="/books"
          hrefLabel="All books"
        />
        <BookRail books={popular.map((b) => ({ book: b }))} />
      </section>

      <section className="pb-12">
        <SectionHead
          index="05"
          sub="The reading room"
          title="From readers you follow"
          href="/readers"
          hrefLabel="All readers"
        />
        {friendActs.length > 0 ? (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {friendActs.slice(0, 6).map((act) => (
              <FriendActivityCard key={act.log.id} act={act} />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-start gap-4 rounded-lg border border-dashed border-ink/25 bg-paper-2/40 p-8 sm:flex-row sm:items-center sm:justify-between">
            <p className="max-w-lg text-sm leading-relaxed text-ink-2">
              You’re reading alone for now. Follow a few kindred readers and
              their fresh finishes will appear here — the best recommendations
              are borrowed.
            </p>
            <Link
              href="/readers"
              className="shrink-0 rounded-full bg-ink px-6 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-paper transition-colors hover:bg-rust"
            >
              Meet the readers
            </Link>
          </div>
        )}
      </section>

      {reviews.length > 0 && (
        <section className="pb-4">
          <SectionHead
            index="06"
            sub="Marginalia"
            title="Notes from other readers"
          />
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {reviews.slice(0, 3).map((r) => (
              <ReviewTeaser key={r.log.id} review={r} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function Onboarding({ popular }: { popular: BookMeta[] }) {
  return (
    <section className="pb-12">
      <div className="rounded-lg border border-dashed border-ink/25 bg-paper-2/40 p-8 sm:p-10">
        <p className="kicker text-rust">Begin here</p>
        <h2 className="display mt-3 max-w-2xl text-3xl leading-tight sm:text-4xl">
          Rate three books you’ve read, and Folio will start recommending.
        </h2>
        <p className="mt-3 max-w-lg text-sm leading-relaxed text-ink-2">
          The more honest your stars, the eerier the recommendations. These are
          the books everyone else is loving right now — a fine place to begin.
        </p>
      </div>
      <div className="mt-8">
        <BookGrid books={popular.map((b) => ({ book: b }))} />
      </div>
    </section>
  );
}
