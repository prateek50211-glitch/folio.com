import { NextResponse } from "next/server";
import { searchLibrary } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") ?? "").trim();
  if (q.length < 2) return NextResponse.json({ books: [], authors: [] });

  const { books, authors } = await searchLibrary(q);
  return NextResponse.json(
    {
      books: books.slice(0, 5).map((b) => ({
        slug: b.slug,
        title: b.title,
        author: b.author.name,
        year: b.publishedYear,
        coverUrl: b.coverUrl,
        avg: b.avgRating,
      })),
      authors: authors.slice(0, 3).map((a) => ({
        slug: a.slug,
        name: a.name,
        bookCount: a.bookCount,
        photoUrl: a.photoUrl,
      })),
    },
    { headers: { "Cache-Control": "no-store" } },
  );
}
