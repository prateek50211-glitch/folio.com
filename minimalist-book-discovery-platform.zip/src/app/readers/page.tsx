import type { Metadata } from "next";
import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { getReadersDirectory } from "@/lib/data";
import { Avatar } from "@/components/Avatar";
import { FollowButton } from "@/components/FollowButton";
import { Users } from "lucide-react";
import { monthYear, plural } from "@/lib/utils";

export const metadata: Metadata = { title: "Readers" };
export const dynamic = "force-dynamic";

export default async function ReadersPage() {
  const user = await getSessionUser();
  const readers = await getReadersDirectory(user?.id ?? null);

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <header className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="kicker flex items-center gap-2 text-rust">
            <Users size={13} /> The reading room
          </p>
          <h1 className="display mt-3 text-5xl leading-[1.0] sm:text-6xl">
            Meet the other
            <br />
            <em className="text-ink-2">night-stand stackers.</em>
          </h1>
          <p className="mt-5 max-w-lg text-sm leading-relaxed text-ink-2">
            Browse any reader’s shelf, borrow their taste, follow the ones
            whose stars you trust. Their recent reads surface on your homepage.
          </p>
        </div>
        <p className="mb-1 text-sm text-ink-2">
          <span className="display text-2xl text-ink">{readers.length}</span>{" "}
          readers inside
        </p>
      </header>

      <div className="mt-12 grid gap-x-10 gap-y-12 sm:grid-cols-2 lg:grid-cols-3">
        {readers.map((r, i) => (
          <article key={r.id} className="relative border-t border-ink/15 pt-5">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <span className="display pointer-events-none absolute -left-1 top-4 text-3xl text-ink/10">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <Avatar name={r.displayName} className="ml-8 h-12 w-12 text-base" />
                <div>
                  <Link
                    href={`/readers/${r.username}`}
                    className="display text-xl leading-tight transition-colors hover:text-rust"
                  >
                    {r.displayName}
                  </Link>
                  <p className="mt-0.5 text-xs text-ink-2">
                    @{r.username} · since {monthYear(r.createdAt)}
                  </p>
                </div>
              </div>
              {r.username !== user?.username && (
                <FollowButton
                  username={r.username}
                  initiallyFollowing={r.following}
                  hasUser={!!user}
                  size="sm"
                />
              )}
            </div>

            <div className="ml-8 mt-5 grid grid-cols-3 gap-2 border-y border-ink/10 py-3 text-center">
              {[
                { n: r.readCount, label: "Read" },
                { n: r.avgRating ? r.avgRating.toFixed(1) : "—", label: "Avg ★" },
                { n: r.reviewCount, label: "Notes" },
              ].map((s) => (
                <div key={s.label}>
                  <p className="display text-xl leading-none">{s.n}</p>
                  <p className="kicker mt-1.5 text-ink-3">{s.label}</p>
                </div>
              ))}
            </div>

            <div className="ml-8 mt-3.5 flex items-center justify-between text-xs text-ink-2">
              <p>
                {r.topGenre ? (
                  <>
                    Mostly{" "}
                    <Link
                      href={`/books?genre=${encodeURIComponent(r.topGenre)}`}
                      className="u-sweep font-medium text-rust"
                    >
                      {r.topGenre.toLowerCase()}
                    </Link>
                  </>
                ) : (
                  "Taste unwritten"
                )}
              </p>
              <p className="text-ink-3">
                {r.followerCount > 0
                  ? plural(r.followerCount, "follower")
                  : "no followers yet"}
              </p>
            </div>
            <Link
              href={`/readers/${r.username}`}
              className="kicker ml-8 mt-4 inline-block text-ink-3 transition-colors hover:text-rust"
            >
              Open their shelf →
            </Link>
          </article>
        ))}
      </div>
    </div>
  );
}
