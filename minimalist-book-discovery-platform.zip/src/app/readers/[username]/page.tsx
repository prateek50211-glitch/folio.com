import type { Metadata } from "next";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { getReaderByUsername } from "@/lib/data";
import { Avatar } from "@/components/Avatar";
import { FollowButton } from "@/components/FollowButton";
import { BookCover } from "@/components/BookCover";
import { RatingStars } from "@/components/RatingStars";
import { SectionHead } from "@/components/SectionHead";
import { BookGrid } from "@/components/BookCard";
import { Heart } from "lucide-react";
import { monthYear, plural } from "@/lib/utils";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ username: string }>;
}): Promise<Metadata> {
  const { username } = await params;
  return { title: `@${username}’s shelf` };
}

export const dynamic = "force-dynamic";

export default async function ReaderProfilePage({
  params,
}: {
  params: Promise<{ username: string }>;
}) {
  const { username } = await params;
  const user = await getSessionUser();
  if (user?.username === username) redirect("/you");

  const data = await getReaderByUsername(username, user?.id ?? null);
  if (!data) notFound();
  const { reader, withBooks } = data;

  const reading = withBooks.filter((x) => x.log.status === "reading").slice(0, 8);
  const read = withBooks
    .filter((x) => x.log.status === "read")
    .sort((a, z) => z.log.createdAt.getTime() - a.log.createdAt.getTime())
    .slice(0, 12);
  const want = withBooks.filter((x) => x.log.status === "want");
  const notes = withBooks.filter((x) => x.log.review);
  const loved = withBooks
    .filter((x) => x.log.liked || parseFloat(x.log.rating ?? "0") >= 5)
    .map((x) => x.book);

  // taste bars
  const genreCount = new Map<string, number>();
  for (const { log, book } of withBooks) {
    if (log.status !== "read") continue;
    for (const g of book.genres) genreCount.set(g, (genreCount.get(g) ?? 0) + 1);
  }
  const topGenres = [...genreCount.entries()].sort((a, z) => z[1] - a[1]).slice(0, 5);
  const maxGenre = Math.max(1, ...topGenres.map(([, c]) => c));
  const firstName = reader.displayName.split(" ")[0];

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <p className="kicker mb-8 text-ink-3">
        <Link href="/readers" className="transition-colors hover:text-rust">
          Readers
        </Link>
        <span className="mx-2 text-ink/25">/</span>@{reader.username}
      </p>

      {/* HEADER */}
      <header className="flex flex-col gap-8 border-b border-ink/10 pb-10 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-5">
          <Avatar name={reader.displayName} className="h-16 w-16 text-2xl" />
          <div>
            <h1 className="display text-4xl leading-none sm:text-5xl">{reader.displayName}</h1>
            <p className="mt-2 text-sm text-ink-2">
              @{reader.username} · reading since {monthYear(reader.createdAt)} ·{" "}
              {plural(reader.followerCount, "follower")}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex gap-6 text-center sm:gap-7">
            {[
              { n: reader.readCount, label: "Read" },
              { n: reader.avgRating ? reader.avgRating.toFixed(1) : "—", label: "Avg ★" },
              { n: reader.likedCount, label: "Loved" },
            ].map((s) => (
              <div key={s.label}>
                <p className="display text-3xl leading-none">{s.n}</p>
                <p className="kicker mt-1.5 text-ink-3">{s.label}</p>
              </div>
            ))}
          </div>
          <FollowButton
            username={reader.username}
            initiallyFollowing={data.reader.following}
            hasUser={!!user}
          />
        </div>
      </header>

      {/* TASTE + LOVED */}
      <section className="mt-12 grid gap-10 md:grid-cols-2">
        <div className="border-t border-ink/15 pt-5">
          <p className="kicker mb-5 text-rust">{firstName}’s taste, in bars</p>
          {topGenres.length ? (
            <div className="space-y-3.5">
              {topGenres.map(([genre, count]) => (
                <div key={genre}>
                  <div className="mb-1 flex items-baseline justify-between text-sm">
                    <Link
                      href={`/books?genre=${encodeURIComponent(genre)}`}
                      className="font-medium transition-colors hover:text-rust"
                    >
                      {genre}
                    </Link>
                    <span className="text-xs text-ink-3">{plural(count, "book")}</span>
                  </div>
                  <div className="h-[6px] overflow-hidden rounded-full bg-paper-3">
                    <div
                      className="h-full rounded-full bg-rust/80"
                      style={{ width: `${(count / maxGenre) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm italic text-ink-3">Taste still unwritten.</p>
          )}
        </div>
        <div className="border-t border-ink/15 pt-5">
          <p className="kicker mb-5 text-rust">Five-star shelf</p>
          {loved.length ? (
            <div className="flex flex-wrap gap-2">
              {loved.slice(0, 6).map((b) => (
                <Link
                  key={b.id}
                  href={`/books/${b.slug}`}
                  className="rounded-full border border-ink/15 px-3.5 py-2 text-xs text-ink-2 transition-colors hover:border-rust hover:text-rust"
                >
                  {b.title}
                </Link>
              ))}
            </div>
          ) : (
            <p className="text-sm italic text-ink-3">
              Nothing has earned the fifth star yet. A tough room.
            </p>
          )}
        </div>
      </section>

      {reading.length > 0 && (
        <section className="mt-14">
          <SectionHead index="01" sub="In progress" title={`What ${firstName} is reading`} />
          <BookGrid books={reading.map(({ book }) => ({ book }))} />
        </section>
      )}

      <section className="mt-14">
        <SectionHead index="02" sub="Diary" title="Recent reading" />
        {read.length === 0 ? (
          <p className="border-t border-ink/10 py-10 text-sm italic text-ink-3">
            A quiet diary so far.
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-x-4 gap-y-8 sm:grid-cols-4 md:grid-cols-6">
            {read.map(({ log, book }) => (
              <Link key={log.id} href={`/books/${book.slug}`} className="group">
                <div className="lift">
                  <BookCover title={book.title} author={book.author.name} src={book.coverUrl} />
                </div>
                <div className="mt-2.5 flex items-center gap-1.5">
                  {log.rating ? (
                    <RatingStars rating={parseFloat(log.rating)} size={10} gap={1.5} />
                  ) : (
                    <span className="text-[11px] italic text-ink-3">unrated</span>
                  )}
                  {log.liked && <Heart size={10} className="text-rust" fill="currentColor" />}
                </div>
                <p className="mt-1 text-[11px] uppercase tracking-[0.12em] text-ink-3">
                  {monthYear(log.createdAt)}
                </p>
              </Link>
            ))}
          </div>
        )}
      </section>

      {want.length > 0 && (
        <section className="mt-14">
          <SectionHead index="03" sub="The pile" title={`${firstName} wants to read`} />
          <BookGrid books={want.map(({ book }) => ({ book }))} />
        </section>
      )}

      {notes.length > 0 && (
        <section className="mt-14">
          <SectionHead index="04" sub="Marginalia" title={`${firstName}’s notes`} />
          <div className="divide-y divide-ink/10 border-y border-ink/10">
            {notes.slice(0, 10).map(({ log, book }) => (
              <div key={log.id} className="grid gap-4 py-6 sm:grid-cols-[64px_1fr]">
                <Link href={`/books/${book.slug}`} className="block w-16 shrink-0">
                  <BookCover title={book.title} author={book.author.name} src={book.coverUrl} />
                </Link>
                <div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                    <Link href={`/books/${book.slug}`} className="display text-lg transition-colors hover:text-rust">
                      {book.title}
                    </Link>
                    {log.rating && <RatingStars rating={parseFloat(log.rating)} size={11} gap={1.5} />}
                    <span className="text-[11px] uppercase tracking-[0.12em] text-ink-3">
                      {monthYear(log.createdAt)}
                    </span>
                  </div>
                  <p className="mt-2 max-w-3xl text-[15px] leading-relaxed text-ink/90">{log.review}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
