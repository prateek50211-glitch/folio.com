import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getBookBySlug, getUserLogFor } from "@/lib/data";
import { getSessionUser } from "@/lib/auth";
import { BookCover } from "@/components/BookCover";
import { RatingStars } from "@/components/RatingStars";
import { LogControl } from "@/components/LogControl";
import { WantToggle } from "@/components/WantToggle";
import { ReviewRow } from "@/components/ReviewCard";
import { BookRail } from "@/components/BookCard";
import { SectionHead } from "@/components/SectionHead";
import { BookOpen, Bookmark, Users } from "lucide-react";
import type { LogStatus } from "@/db/schema";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const data = await getBookBySlug(slug);
  return { title: data ? `${data.book.title} by ${data.book.author.name}` : "Book" };
}

export default async function BookPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const [data, user] = await Promise.all([getBookBySlug(slug), getSessionUser()]);
  if (!data) notFound();
  const { book, moreByAuthor, alsoEnjoyed, dist, reviews } = data;

  const userLog = await getUserLogFor(user?.id, book.id);
  const initial = userLog
    ? {
        status: userLog.status as LogStatus,
        rating: userLog.rating ? parseFloat(userLog.rating) : null,
        liked: userLog.liked,
        review: userLog.review,
      }
    : null;

  const maxDist = Math.max(1, ...dist);

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-10 sm:px-8 sm:py-14">
      <p className="kicker mb-8 text-ink-3">
        <Link href="/books" className="transition-colors hover:text-rust">
          Books
        </Link>
        <span className="mx-2 text-ink/25">/</span>
        {book.genres[0] && (
          <Link
            href={`/books?genre=${encodeURIComponent(book.genres[0])}`}
            className="transition-colors hover:text-rust"
          >
            {book.genres[0]}
          </Link>
        )}
      </p>

      <div className="grid gap-10 lg:grid-cols-[290px_1fr] lg:gap-14">
        {/* LEFT — cover & actions */}
        <aside className="mx-auto w-full max-w-[300px] lg:sticky lg:top-28 lg:mx-0 lg:self-start">
          <div className="lift">
            <BookCover
              title={book.title}
              author={book.author.name}
              src={book.coverUrl}
              eager
            />
          </div>
          <div className="mt-6 space-y-2.5">
            <LogControl
              book={{
                id: book.id,
                title: book.title,
                slug: book.slug,
                publishedYear: book.publishedYear,
                authorName: book.author.name,
                coverUrl: book.coverUrl,
              }}
              initial={initial}
              hasUser={!!user}
            />
            <WantToggle
              bookId={book.id}
              active={initial?.status === "want"}
              hasUser={!!user}
            />
          </div>

          {/* rating summary */}
          <div className="mt-7 border-t border-ink/10 pt-6">
            <div className="flex items-end justify-between">
              <p className="display text-6xl leading-none">
                {book.avgRating ? book.avgRating.toFixed(2) : "—"}
              </p>
              <div className="pb-1 text-right">
                {book.avgRating && (
                  <RatingStars rating={book.avgRating} size={12} />
                )}
                <p className="mt-1.5 text-[11px] uppercase tracking-[0.14em] text-ink-3">
                  {book.ratingCount} rating{book.ratingCount === 1 ? "" : "s"}
                </p>
              </div>
            </div>
            <div className="mt-5 space-y-1.5">
              {[5, 4, 3, 2, 1].map((star, i) => {
                const n = dist[i];
                return (
                  <div key={star} className="flex items-center gap-2.5">
                    <span className="w-3 text-right text-[11px] tabular-nums text-ink-3">
                      {star}
                    </span>
                    <div className="h-[5px] flex-1 overflow-hidden rounded-full bg-paper-3">
                      <div
                        className="h-full rounded-full bg-star/90"
                        style={{ width: `${(n / maxDist) * 100}%` }}
                      />
                    </div>
                    <span className="w-6 text-[11px] tabular-nums text-ink-3">{n}</span>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 space-y-2.5 text-[13px] text-ink-2">
              <p className="flex items-center gap-2.5">
                <BookOpen size={13} className="text-ink-3" />
                Read by <span className="font-semibold text-ink">{book.readCount}</span> readers
              </p>
              <p className="flex items-center gap-2.5">
                <Bookmark size={13} className="text-ink-3" />
                On <span className="font-semibold text-ink">{book.wantCount}</span> wish shelves
              </p>
              <p className="flex items-center gap-2.5">
                <Users size={13} className="text-ink-3" />
                <span className="font-semibold text-ink">{book.readingCount}</span> reading it now
              </p>
            </div>
          </div>
        </aside>

        {/* RIGHT — main */}
        <div className="min-w-0">
          <h1 className="display display-tight text-[clamp(2.4rem,5vw,4rem)] leading-[0.98]">
            {book.title}
          </h1>
          <p className="mt-4 text-lg text-ink-2">
            by{" "}
            <Link
              href={`/authors/${book.author.slug}`}
              className="u-sweep font-medium text-rust"
            >
              {book.author.name}
            </Link>
            {book.publishedYear ? (
              <span className="text-ink-3"> · {book.publishedYear}</span>
            ) : null}
            {book.pages ? <span className="text-ink-3"> · {book.pages} pages</span> : null}
          </p>

          <div className="mt-5 flex flex-wrap gap-2">
            {book.genres.map((g) => (
              <Link
                key={g}
                href={`/books?genre=${encodeURIComponent(g)}`}
                className="rounded-full border border-ink/15 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-2 transition-colors hover:border-ink hover:text-ink"
              >
                {g}
              </Link>
            ))}
          </div>

          <blockquote className="mt-8 max-w-2xl border-l-2 border-rust/70 pl-5">
            <p className="display text-xl leading-relaxed text-ink/90 sm:text-[22px]">
              {book.description}
            </p>
          </blockquote>

          {initial?.status === "read" && (
            <div className="mt-8 flex items-center gap-4 rounded-md border border-ink/10 bg-paper-2/60 px-5 py-4">
              <p className="kicker text-ink-2">You rated it</p>
              <RatingStars rating={initial.rating} size={14} />
              {initial.rating && (
                <span className="display text-xl">{initial.rating}</span>
              )}
              {initial.liked && (
                <span className="ml-auto rounded-full bg-rust/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-rust">
                  Loved
                </span>
              )}
            </div>
          )}

          {/* REVIEWS */}
          <section className="mt-12">
            <SectionHead
              index="01"
              sub="Marginalia"
              title={`What readers say`}
            />
            {reviews.length > 0 ? (
              <div>
                {reviews.map((r) => (
                  <ReviewRow key={r.log.id} review={r} />
                ))}
              </div>
            ) : (
              <p className="border-t border-ink/10 py-8 text-sm italic text-ink-3">
                No notes in the margins yet. Yours could be the first.
              </p>
            )}
          </section>

          {moreByAuthor.length > 0 && (
            <section className="mt-12">
              <SectionHead
                index="02"
                sub="Same pen"
                title={`More by ${book.author.name}`}
                href={`/authors/${book.author.slug}`}
                hrefLabel="Author page"
              />
              <BookRail books={moreByAuthor.map((b) => ({ book: b }))} />
            </section>
          )}

          {alsoEnjoyed.length > 0 && (
            <section className="mt-12">
              <SectionHead
                index="03"
                sub="Kindred shelves"
                title="Readers also loved"
              />
              <BookRail books={alsoEnjoyed.map((b) => ({ book: b }))} />
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
