import Link from "next/link";
import type { Metadata } from "next";
import { GENRES } from "@/db/seed-data";
import { MOODS, getBrowseBooks, getMoodBooks, getMoodById } from "@/lib/data";
import { BookGrid } from "@/components/BookCard";
import { cn } from "@/lib/utils";
import { Sparkles, X } from "lucide-react";

export const metadata: Metadata = { title: "Books" };
export const dynamic = "force-dynamic";

const SORTS = [
  { id: "popular", label: "Most read" },
  { id: "rating", label: "Highest rated" },
  { id: "newest", label: "Newest" },
  { id: "title", label: "A – Z" },
] as const;

export default async function BooksPage({
  searchParams,
}: {
  searchParams: Promise<{ genre?: string; sort?: string; mood?: string }>;
}) {
  const { genre, sort, mood: moodId } = await searchParams;
  const mood = getMoodById(moodId);
  const activeGenre =
    genre && GENRES.includes(genre as (typeof GENRES)[number]) ? genre : "All";
  const activeSort = SORTS.some((s) => s.id === sort) ? (sort as string) : "popular";

  const list = mood
    ? await getMoodBooks(mood, 36)
    : await getBrowseBooks(activeGenre, activeSort);

  const hrefFor = (g: string, s: string) => {
    const params = new URLSearchParams();
    if (g !== "All") params.set("genre", g);
    if (s !== "popular") params.set("sort", s);
    const qs = params.toString();
    return qs ? `/books?${qs}` : "/books";
  };

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <header className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="kicker text-rust">{mood ? "A mood, honored" : "The stacks"}</p>
          <h1 className="display mt-3 max-w-3xl text-5xl leading-[1.02] sm:text-6xl">
            {mood ? (
              <>
                {mood.label}<span className="text-rust">.</span>
              </>
            ) : activeGenre === "All" ? (
              "Every book in the room."
            ) : (
              <>
                Everything <em className="text-ink-2">{activeGenre.toLowerCase()}.</em>
              </>
            )}
          </h1>
          {mood && (
            <p className="display mt-3 text-xl italic text-ink-2">{mood.tagline}</p>
          )}
        </div>
        <p className="mb-1 text-sm text-ink-2">
          <span className="display text-2xl text-ink">{list.length}</span>{" "}
          {list.length === 1 ? "title" : "titles"}
        </p>
      </header>

      {/* mood chips */}
      <div className="no-scrollbar -mx-5 mt-8 flex items-center gap-2 overflow-x-auto px-5 pb-1 sm:-mx-8 sm:px-8">
        <span className="kicker flex shrink-0 items-center gap-1.5 pr-1 text-rust">
          <Sparkles size={12} /> Mood
        </span>
        {MOODS.map((m) => (
          <Link
            key={m.id}
            href={`/books?mood=${m.id}`}
            className={cn(
              "shrink-0 rounded-full border px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] transition-colors",
              mood?.id === m.id
                ? "border-rust bg-rust text-paper"
                : "border-rust/30 text-rust hover:border-rust hover:bg-rust/5",
            )}
          >
            {m.label}
          </Link>
        ))}
        {mood && (
          <Link
            href="/books"
            className="flex shrink-0 items-center gap-1 rounded-full border border-ink/20 px-3.5 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-2 transition-colors hover:border-ink hover:text-ink"
          >
            <X size={11} /> Clear
          </Link>
        )}
      </div>

      {/* genre chips */}
      <div className="no-scrollbar -mx-5 mt-3 flex gap-2 overflow-x-auto px-5 pb-1 sm:-mx-8 sm:px-8">
        <span className="kicker flex shrink-0 items-center pr-1 text-ink-3">Genre</span>
        {["All", ...GENRES].map((g) => (
          <Link
            key={g}
            href={hrefFor(g, activeSort)}
            className={cn(
              "shrink-0 rounded-full border px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] transition-colors",
              !mood && g === activeGenre
                ? "border-ink bg-ink text-paper"
                : "border-ink/20 text-ink-2 hover:border-ink hover:text-ink",
            )}
          >
            {g}
          </Link>
        ))}
      </div>

      {/* sort */}
      {!mood && (
        <div className="mt-6 flex items-center gap-1 border-y border-ink/10 py-2.5">
          <span className="kicker mr-3 text-ink-3">Order</span>
          {SORTS.map((s) => (
            <Link
              key={s.id}
              href={hrefFor(activeGenre, s.id)}
              className={cn(
                "rounded-full px-3.5 py-1.5 text-xs transition-colors",
                s.id === activeSort
                  ? "bg-paper-2 font-semibold text-ink"
                  : "text-ink-2 hover:text-ink",
              )}
            >
              {s.label}
            </Link>
          ))}
        </div>
      )}

      <div className="mt-10">
        {list.length ? (
          <BookGrid books={list.map((b) => ({ book: b }))} />
        ) : (
          <p className="py-20 text-center text-ink-3">
            Nothing shelved here yet. Try another shelf.
          </p>
        )}
      </div>
    </div>
  );
}
