import type { Metadata } from "next";
import Link from "next/link";
import { getLibrary, searchLibrary, getMostCollected } from "@/lib/data";
import { GENRES } from "@/db/seed-data";
import {
  slugify,
  searchOpenLibraryAuthors,
  searchOpenLibraryBooks,
} from "@/lib/openlibrary";
import { getSessionUser } from "@/lib/auth";
import { BookGrid } from "@/components/BookCard";
import { SectionHead } from "@/components/SectionHead";
import { AuthorPortrait } from "@/components/AuthorPortrait";
import { OLBookCard } from "@/components/OLBookCard";
import { Globe2, MoveRight, Search } from "lucide-react";

export const metadata: Metadata = { title: "Search" };
export const dynamic = "force-dynamic";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const query = (q ?? "").trim();
  const user = await getSessionUser();

  const [results, popular] = await Promise.all([
    query ? searchLibrary(query) : Promise.resolve(null),
    query ? Promise.resolve(null) : getMostCollected(12),
  ]);

  // Live Open Library search (parallel with everything else)
  const [olBooks, olAuthors, lib] = query
    ? await Promise.all([
        searchOpenLibraryBooks(query, 12).catch(() => []),
        searchOpenLibraryAuthors(query, 4).catch(() => []),
        getLibrary(),
      ])
    : [[], [], null];

  const localSlugs = lib ? new Set([...lib.books.values()].map((b) => b.slug)) : new Set<string>();

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <header className="max-w-2xl">
        <p className="kicker flex items-center gap-2 text-rust">
          <Search size={12} /> Instant search, infinite stacks
        </p>
        <h1 className="display mt-3 text-5xl leading-[1.0] sm:text-6xl">
          {query ? (
            <>
              Results for <em className="text-rust">“{query}”</em>
            </>
          ) : (
            <>
              Find any book
              <br />
              <em className="text-ink-2">that exists.</em>
            </>
          )}
        </h1>
        <form action="/search" className="mt-8">
          <div className="flex items-center gap-3 border-b-2 border-ink/70 pb-2.5 focus-within:border-rust">
            <Search size={18} className="text-ink-3" />
            <input
              name="q"
              defaultValue={query}
              autoFocus={!query}
              autoComplete="off"
              placeholder="A title, an author, a mood…"
              className="w-full bg-transparent text-xl outline-none placeholder:text-ink-3"
            />
            <button
              type="submit"
              aria-label="Search"
              className="shrink-0 rounded-full bg-ink p-2.5 text-paper transition-colors hover:bg-rust"
            >
              <MoveRight size={15} />
            </button>
          </div>
        </form>
      </header>

      {!query && (
        <>
          <p className="mt-6 max-w-2xl text-sm leading-relaxed text-ink-2">
            The local shelves below are curated and reviewed; if what you want
            isn’t here, the same search sweeps the whole Open Library archive —
            one click inscribes any discovery onto your shelf.
          </p>
          <div className="no-scrollbar -mx-5 mt-10 flex gap-2 overflow-x-auto px-5 sm:-mx-8 sm:px-8">
            {GENRES.map((g) => (
              <Link
                key={g}
                href={`/books?genre=${encodeURIComponent(g)}`}
                className="shrink-0 rounded-full border border-ink/20 px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-2 transition-colors hover:border-ink hover:text-ink"
              >
                {g}
              </Link>
            ))}
          </div>
          {popular && (
            <section className="mt-12">
              <SectionHead index="01" sub="Crowd wisdom" title="Most collected" href="/books" hrefLabel="All books" />
              <BookGrid books={popular.map((b) => ({ book: b }))} />
            </section>
          )}
        </>
      )}

      {results && (
        <>
          {/* -------- local results -------- */}
          <div className="mt-12">
            <p className="kicker text-ink-3">In our stacks</p>
          </div>
          {results.books.length === 0 && results.authors.length === 0 ? (
            <p className="mt-6 border border-dashed border-ink/25 bg-paper-2/40 p-8 text-center text-sm italic text-ink-2">
              Not shelved here yet — but the Open Library below almost
              certainly has it.
            </p>
          ) : (
            <>
              {results.authors.length > 0 && (
                <section className="mt-8">
                  <SectionHead index="01" sub="Voices" title="Authors" />
                  <div className="grid gap-x-10 sm:grid-cols-2">
                    {results.authors.map((a) => (
                      <Link
                        key={a.id}
                        href={`/authors/${a.slug}`}
                        className="group flex items-center gap-4 border-b border-ink/10 py-4 transition-colors hover:bg-paper-2/50"
                      >
                        <div className="h-14 w-11 shrink-0">
                          <AuthorPortrait name={a.name} src={a.photoUrl} className="h-full w-full" />
                        </div>
                        <div className="min-w-0">
                          <p className="display text-xl leading-tight transition-colors group-hover:text-rust">{a.name}</p>
                          <p className="mt-0.5 text-xs text-ink-2">
                            {a.nationality} · {a.bookCount} {a.bookCount === 1 ? "book" : "books"}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </section>
              )}
              {results.books.length > 0 && (
                <section className="mt-10">
                  <SectionHead
                    index={results.authors.length > 0 ? "02" : "01"}
                    sub="Volumes"
                    title="Books"
                  />
                  <BookGrid books={results.books.map((b) => ({ book: b }))} />
                </section>
              )}
            </>
          )}

          {/* -------- Open Library results -------- */}
          {(olBooks.length > 0 || olAuthors.length > 0) && (
            <div className="mt-16">
              <div className="flex flex-wrap items-baseline justify-between gap-3 border-t-2 border-ink pt-4">
                <p className="kicker flex items-center gap-2 text-rust">
                  <Globe2 size={13} /> The wider world · Open Library
                </p>
                <p className="text-xs italic text-ink-3">
                  “Inscribe” adds a discovery to our public stacks and your shelf in one click.
                </p>
              </div>

              {olAuthors.length > 0 && (
                <section className="mt-8">
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                    {olAuthors.map((a) => (
                      <Link
                        key={a.key}
                        href={`/explore/author/${a.key}`}
                        className="group flex items-center gap-3.5 rounded-md border border-ink/10 bg-paper-2/40 p-3.5 transition-colors hover:border-rust/50"
                      >
                        <div className="h-12 w-10 shrink-0">
                          <AuthorPortrait name={a.name} src={a.photoUrl} className="h-full w-full" />
                        </div>
                        <div className="min-w-0">
                          <p className="display truncate text-lg leading-tight transition-colors group-hover:text-rust">{a.name}</p>
                          <p className="mt-0.5 truncate text-xs text-ink-2">
                            {a.topWork ? `“${a.topWork}”` : `${a.workCount} works`}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </section>
              )}

              {olBooks.length > 0 && (
                <section className="mt-8 grid grid-cols-3 gap-x-4 gap-y-10 sm:grid-cols-4 sm:gap-x-5 md:grid-cols-5 lg:grid-cols-6">
                  {olBooks.map((payload) => (
                    <OLBookCard
                      key={`${payload.title}-${payload.authorName}`}
                      payload={payload}
                      hasUser={!!user}
                      localSlug={localSlugs.has(slugify(`${payload.title}-${payload.authorName}`)) ? slugify(`${payload.title}-${payload.authorName}`) : null}
                    />
                  ))}
                </section>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
