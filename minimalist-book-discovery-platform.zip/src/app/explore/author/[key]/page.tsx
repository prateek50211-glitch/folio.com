import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { authors } from "@/db/schema";
import { ilike } from "drizzle-orm";
import { getSessionUser } from "@/lib/auth";
import { getLibrary } from "@/lib/data";
import { getOLAuthorPage, slugify } from "@/lib/openlibrary";
import { AuthorPortrait } from "@/components/AuthorPortrait";
import { OLBookCard } from "@/components/OLBookCard";
import { SectionHead } from "@/components/SectionHead";
import { ArrowUpRight, Globe2 } from "lucide-react";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ key: string }>;
}): Promise<Metadata> {
  const { key } = await params;
  const doc = await getOLAuthorPage(key).catch(() => null);
  return { title: doc ? doc.name : "Author" };
}

export const dynamic = "force-dynamic";

export default async function ExploreAuthorPage({
  params,
}: {
  params: Promise<{ key: string }>;
}) {
  const { key } = await params;
  const [doc, user, lib] = await Promise.all([
    getOLAuthorPage(key),
    getSessionUser(),
    getLibrary(),
  ]);
  if (!doc) notFound();

  // does a curated local page already exist for this author?
  const localAuthor = (
    await db.select().from(authors).where(ilike(authors.name, doc.name)).limit(1)
  )[0];

  const localSlugs = new Set([...lib.books.values()].map((b) => b.slug));

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-12 sm:px-8 sm:py-16">
      <p className="kicker mb-8 flex items-center gap-2 text-ink-3">
        <Globe2 size={12} className="text-rust" />
        Open Library archive
        <span className="mx-1 text-ink/25">/</span>
        {doc.name}
      </p>

      <header className="grid gap-10 md:grid-cols-[1fr_220px] lg:grid-cols-[1fr_260px] lg:gap-16">
        <div>
          <p className="kicker text-rust">
            {doc.birthDate ? `b. ${doc.birthDate} · ` : ""}
            {doc.works.length} works catalogued
          </p>
          <h1 className="display display-tight mt-4 text-[clamp(2.6rem,6vw,5rem)] leading-[0.97]">
            {doc.name}
          </h1>
          {doc.bio && (
            <p className="display mt-6 max-w-xl text-lg leading-relaxed text-ink-2">
              {doc.bio}
            </p>
          )}
          <div className="mt-7 flex flex-wrap items-center gap-3">
            {localAuthor ? (
              <Link
                href={`/authors/${localAuthor.slug}`}
                className="group flex items-center gap-2 rounded-full border border-ink/20 px-4 py-2 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-2 transition-colors hover:border-rust hover:text-rust"
              >
                Curated page in our stacks
                <ArrowUpRight size={13} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
              </Link>
            ) : (
              <p className="rounded-full border border-dashed border-ink/25 px-4 py-2 text-[11px] uppercase tracking-[0.14em] text-ink-3">
                Not yet curated — inscribe a book to begin the record
              </p>
            )}
          </div>
        </div>
        <div className="mx-auto w-full max-w-[220px] md:mx-0">
          <AuthorPortrait
            name={doc.name}
            src={doc.photoUrl}
            className="aspect-[3/4] w-full shadow-[0_20px_40px_-20px_rgba(23,19,13,0.45)]"
          />
          <p className="kicker mt-3 text-center text-ink-3">Open Library</p>
        </div>
      </header>

      <section className="mt-14">
        <SectionHead
          index="01"
          sub="The archive"
          title={`Works by ${doc.name.split(" ").slice(-1)[0]}`}
        />
        <p className="mb-8 max-w-xl text-sm leading-relaxed text-ink-2">
          Inscribing a title imports the edition into our public stacks and
          places it on your shelf — one motion, no forms.
        </p>
        {doc.works.length ? (
          <div className="grid grid-cols-3 gap-x-4 gap-y-10 sm:grid-cols-4 sm:gap-x-5 md:grid-cols-5 lg:grid-cols-6">
            {doc.works.map((payload) => {
              const slug = slugify(`${payload.title}-${payload.authorName}`);
              return (
                <OLBookCard
                  key={payload.olKey || slug}
                  payload={payload}
                  hasUser={!!user}
                  localSlug={localSlugs.has(slug) ? slug : null}
                />
              );
            })}
          </div>
        ) : (
          <p className="py-16 text-center text-sm italic text-ink-3">
            The archive returned no works for this name.
          </p>
        )}
      </section>
    </div>
  );
}
