import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { SignInForm } from "@/components/SignInForm";

export const metadata: Metadata = { title: "Sign in" };

export default async function SignInPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const user = await getSessionUser();
  if (user) redirect("/");
  const { error } = await searchParams;

  return (
    <div className="mx-auto flex max-w-[1240px] flex-col items-center px-5 py-16 sm:px-8 sm:py-24">
      <div className="w-full max-w-md">
        <p className="kicker text-rust">Members & wanderers</p>
        <h1 className="display mt-4 text-5xl leading-[1.02] sm:text-6xl">
          The door
          <br />
          <em className="text-ink-2">is open.</em>
        </h1>
        <SignInForm error={error} />
      </div>
      <div className="mt-16 max-w-md border-l-2 border-rust/60 pl-5">
        <p className="display text-lg leading-relaxed text-ink-2">
          “A reader lives a thousand lives before he dies. The one who never
          reads lives only one.”
        </p>
        <p className="kicker mt-3 text-ink-3">After George R.R. Martin</p>
      </div>
    </div>
  );
}
