"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowUpRight, BookMarked, Check, LibraryBig } from "lucide-react";
import { inscribeFromOLAction, openOLBookAction } from "@/app/actions";
import type { OLBookPayload } from "@/lib/openlibrary";
import { cn } from "@/lib/utils";

export function InscribeButton({
  payload,
  hasUser,
  initiallyLogged = false,
}: {
  payload: OLBookPayload;
  hasUser: boolean;
  initiallyLogged?: boolean;
}) {
  const router = useRouter();
  const [slug, setSlug] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const [pending, start] = useTransition();

  if (initiallyLogged && !slug) {
    return (
      <span className="flex w-full items-center justify-center gap-1.5 rounded-full border border-rust/50 bg-rust/10 px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-rust">
        <Check size={12} /> In the stacks
      </span>
    );
  }

  if (slug) {
    return (
      <Link
        href={`/books/${slug}`}
        className="flex w-full items-center justify-center gap-1.5 rounded-full bg-rust px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-paper transition-colors hover:bg-rust-deep"
      >
        <Check size={12} /> On your shelf →
      </Link>
    );
  }

  return (
    <button
      disabled={pending}
      onClick={() => {
        if (!hasUser) {
          router.push("/sign-in");
          return;
        }
        start(async () => {
          const res = await inscribeFromOLAction(payload, "want");
          if (res.ok) setSlug(res.slug);
          else if (res.error === "signin") router.push("/sign-in");
          else setFailed(true);
        });
      }}
      className={cn(
        "flex w-full items-center justify-center gap-1.5 rounded-full px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.14em] transition-colors disabled:opacity-60",
        failed
          ? "border border-ink/20 text-ink-3"
          : "bg-ink text-paper hover:bg-rust",
      )}
    >
      <BookMarked size={12} />
      {pending ? "Inscribing…" : failed ? "Try again?" : "Inscribe"}
    </button>
  );
}

export function OpenPageButton({
  payload,
  hasUser,
}: {
  payload: OLBookPayload;
  hasUser: boolean;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <button
      disabled={pending}
      onClick={() => {
        if (!hasUser) {
          router.push("/sign-in");
          return;
        }
        start(async () => {
          const res = await openOLBookAction(payload);
          if (res.ok) router.push(`/books/${res.slug}`);
          else if (res.error === "signin") router.push("/sign-in");
        });
      }}
      className="flex w-full items-center justify-center gap-1.5 rounded-full border border-ink/20 px-3 py-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-ink-2 transition-colors hover:border-ink hover:text-ink disabled:opacity-60"
    >
      {pending ? (
        <LibraryBig size={12} className="animate-pulse" />
      ) : (
        <ArrowUpRight size={12} />
      )}
      {pending ? "Opening…" : "Open page"}
    </button>
  );
}
