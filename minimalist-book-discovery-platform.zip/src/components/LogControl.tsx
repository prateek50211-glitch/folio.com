"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Bookmark, Check, Eye, Heart, PenLine, Trash2, X } from "lucide-react";
import { saveLogAction, removeLogAction } from "@/app/actions";
import { StarInput } from "./StarInput";
import { BookCover } from "./BookCover";
import { cn, ratingText } from "@/lib/utils";
import type { LogStatus } from "@/db/schema";

export type LogInitial = {
  status: LogStatus;
  rating: number | null;
  liked: boolean;
  review: string | null;
};

export function LogControl({
  book,
  initial,
  hasUser,
}: {
  book: {
    id: string;
    title: string;
    slug: string;
    publishedYear: number | null;
    authorName: string;
    coverUrl: string | null;
  };
  initial: LogInitial | null;
  hasUser: boolean;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<LogStatus>(initial?.status ?? "read");
  const [rating, setRating] = useState<number | null>(initial?.rating ?? null);
  const [liked, setLiked] = useState(initial?.liked ?? false);
  const [review, setReview] = useState(initial?.review ?? "");
  const [pending, start] = useTransition();
  const [error, setError] = useState(false);

  if (!hasUser) {
    return (
      <Link
        href="/sign-in"
        className="flex w-full items-center justify-center gap-2 rounded-full bg-ink py-3 text-xs font-semibold uppercase tracking-[0.16em] text-paper transition-colors hover:bg-rust"
      >
        <PenLine size={13} />
        Log · Rate · Review
      </Link>
    );
  }

  const statuses: { id: LogStatus; label: string }[] = [
    { id: "want", label: "Want" },
    { id: "reading", label: "Reading" },
    { id: "read", label: "Read" },
  ];

  function save() {
    start(async () => {
      const res = await saveLogAction({
        bookId: book.id,
        status,
        rating: status === "read" ? rating : null,
        liked: status === "read" ? liked : false,
        review: status === "read" ? review : null,
      });
      if (res.ok) {
        setOpen(false);
        router.refresh();
      } else {
        setError(true);
      }
    });
  }

  function remove() {
    start(async () => {
      const res = await removeLogAction(book.id);
      if (res.ok) {
        setOpen(false);
        router.refresh();
      }
    });
  }

  return (
    <>
      <button
        onClick={() => {
          setError(false);
          setOpen(true);
        }}
        className={cn(
          "flex w-full items-center justify-center gap-2 rounded-full py-3 text-xs font-semibold uppercase tracking-[0.16em] transition-colors",
          initial
            ? "border border-ink/25 bg-paper-2 text-ink hover:border-rust hover:text-rust"
            : "bg-ink text-paper hover:bg-rust",
        )}
      >
        {initial ? (
          <>
            <Check size={13} />
            Logged · {initial.status === "read" ? "Read" : initial.status === "reading" ? "Reading" : "Want"}
            {initial.rating ? ` · ${initial.rating}` : ""}
          </>
        ) : (
          <>
            <PenLine size={13} />
            Log · Rate · Review
          </>
        )}
      </button>

      {open && (
        <div
          className="animate-fade fixed inset-0 z-[70] flex items-end justify-center bg-ink/45 p-0 backdrop-blur-[2px] sm:items-center sm:p-6"
          onClick={() => setOpen(false)}
        >
          <div
            className="animate-rise w-full max-w-lg rounded-t-2xl bg-paper p-6 shadow-2xl sm:rounded-lg sm:p-7"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-label={`Log ${book.title}`}
          >
            <div className="flex items-start justify-between gap-4 border-b border-ink/10 pb-5">
              <div className="flex gap-4">
                <div className="w-12 shrink-0">
                  <BookCover
                    title={book.title}
                    author={book.authorName}
                    src={book.coverUrl}
                  />
                </div>
                <div>
                  <h3 className="display text-xl leading-tight">{book.title}</h3>
                  <p className="mt-1 text-sm text-ink-2">
                    {book.authorName}
                    {book.publishedYear ? ` · ${book.publishedYear}` : ""}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                aria-label="Close"
                className="rounded-full p-1.5 text-ink-3 transition-colors hover:bg-paper-2 hover:text-ink"
              >
                <X size={17} />
              </button>
            </div>

            <div className="mt-5">
              <div className="flex rounded-full border border-ink/15 p-1">
                {statuses.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setStatus(s.id)}
                    className={cn(
                      "flex-1 rounded-full py-2 text-[11px] font-semibold uppercase tracking-[0.14em] transition-all",
                      status === s.id
                        ? "bg-ink text-paper shadow"
                        : "text-ink-2 hover:text-ink",
                    )}
                  >
                    {s.id === "want" ? (
                      <span className="flex items-center justify-center gap-1.5">
                        <Bookmark size={11} /> {s.label}
                      </span>
                    ) : s.id === "reading" ? (
                      <span className="flex items-center justify-center gap-1.5">
                        <Eye size={11} /> {s.label}
                      </span>
                    ) : (
                      <span className="flex items-center justify-center gap-1.5">
                        <Check size={11} /> {s.label}
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {status === "read" ? (
              <div className="mt-6 space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="kicker mb-2 text-ink-2">Your rating</p>
                    <StarInput value={rating} onChange={setRating} />
                  </div>
                  <button
                    onClick={() => setLiked((v) => !v)}
                    aria-pressed={liked}
                    className={cn(
                      "flex flex-col items-center gap-1 rounded-full border p-3.5 transition-all",
                      liked
                        ? "border-rust bg-rust/10 text-rust"
                        : "border-ink/15 text-ink-3 hover:border-ink/30 hover:text-ink",
                    )}
                    title="Loved it"
                  >
                    <Heart
                      size={19}
                      fill={liked ? "currentColor" : "none"}
                      strokeWidth={1.8}
                    />
                  </button>
                </div>
                {rating && (
                  <p className="-mt-3 text-xs italic text-ink-2">
                    {ratingText(rating)}
                  </p>
                )}
                <div>
                  <p className="kicker mb-2 text-ink-2">Review (optional)</p>
                  <textarea
                    value={review}
                    onChange={(e) => setReview(e.target.value)}
                    rows={4}
                    maxLength={2000}
                    placeholder="A note, a quote, a feeling — what did it do to you?"
                    className="w-full resize-none rounded-md border border-ink/15 bg-paper-2/60 p-3.5 text-[15px] leading-relaxed placeholder:text-ink-3 focus:border-ink/40"
                  />
                  <p className="mt-1 text-right text-[11px] tabular-nums text-ink-3">
                    {review.length}/2000
                  </p>
                </div>
              </div>
            ) : (
              <p className="mt-6 text-sm leading-relaxed text-ink-2">
                {status === "want"
                  ? "On your shelf it goes. Ratings unlock once you’ve finished — good things come to those who read."
                  : "Currently on your nightstand. Come back and rate it when you turn the last page."}
              </p>
            )}

            {error && (
              <p className="mt-4 text-xs font-medium text-rust">
                You’ll need to sign in again to save this entry.
              </p>
            )}

            <div className="mt-7 flex items-center gap-3">
              {initial && (
                <button
                  onClick={remove}
                  disabled={pending}
                  className="flex items-center gap-1.5 rounded-full px-3 py-2.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-3 transition-colors hover:text-rust disabled:opacity-50"
                >
                  <Trash2 size={13} /> Remove
                </button>
              )}
              <button
                onClick={save}
                disabled={pending}
                className="ml-auto flex-1 rounded-full bg-ink py-3 text-xs font-semibold uppercase tracking-[0.18em] text-paper transition-colors hover:bg-rust disabled:opacity-60 sm:flex-none sm:px-8"
              >
                {pending ? "Shelving…" : "Save to shelf"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
