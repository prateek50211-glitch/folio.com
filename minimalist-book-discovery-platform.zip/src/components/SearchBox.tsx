"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Globe2, Loader2, Search, X } from "lucide-react";
import { cn } from "@/lib/utils";

type Hit = {
  books: {
    slug: string;
    title: string;
    author: string;
    year: number | null;
    coverUrl: string | null;
    avg: number | null;
  }[];
  authors: { slug: string; name: string; bookCount: number; photoUrl: string | null }[];
};

export function SearchBox() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<Hit | null>(null);
  const [loading, setLoading] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) ref.current?.focus();
  }, [open]);

  // debounced instant search
  useEffect(() => {
    const value = q.trim();
    if (value.length < 2) {
      setHits(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(value)}`);
        if (res.ok) setHits(await res.json());
      } catch {
        /* keep previous */
      }
      setLoading(false);
    }, 220);
    return () => clearTimeout(t);
  }, [q]);

  // click outside closes
  useEffect(() => {
    function onDown(e: MouseEvent) {
      if (!wrapRef.current?.contains(e.target as Node)) setHits(null);
    }
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  function goFull() {
    const value = q.trim();
    if (!value) return;
    setOpen(false);
    setHits(null);
    router.push(`/search?q=${encodeURIComponent(value)}`);
  }

  const showPanel = open && q.trim().length >= 2 && (hits !== null || loading);

  return (
    <div ref={wrapRef} className="relative flex items-center">
      <div
        className={cn(
          "flex items-center overflow-hidden rounded-full border transition-all duration-500",
          open ? "w-48 border-ink/25 bg-paper sm:w-72" : "w-0 border-transparent",
        )}
      >
        <input
          ref={ref}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") goFull();
            if (e.key === "Escape") {
              setOpen(false);
              setHits(null);
              setQ("");
            }
          }}
          placeholder="Any book, any author…"
          className="w-full bg-transparent px-3 py-1.5 text-sm placeholder:text-ink-3"
        />
        {loading && open && <Loader2 size={13} className="mr-2.5 animate-spin text-ink-3" />}
      </div>
      <button
        onClick={() => {
          if (open) {
            setOpen(false);
            setHits(null);
            setQ("");
          } else setOpen(true);
        }}
        aria-label={open ? "Close search" : "Search"}
        className="ml-2 flex h-8 w-8 items-center justify-center rounded-full text-ink-2 transition-colors hover:bg-paper-2 hover:text-ink"
      >
        {open ? <X size={16} /> : <Search size={16} />}
      </button>

      {showPanel && (
        <div className="animate-rise absolute right-0 top-11 z-50 w-[320px] rounded-md border border-ink/15 bg-paper p-2 shadow-[0_24px_48px_-16px_rgba(23,19,13,0.4)] sm:w-[360px]">
          {hits && hits.books.length === 0 && hits.authors.length === 0 && !loading && (
            <p className="px-3 py-4 text-sm italic text-ink-3">
              Nothing in the stacks — try the wider world below.
            </p>
          )}
          {hits?.books.map((b) => (
            <Link
              key={b.slug}
              href={`/books/${b.slug}`}
              onClick={() => {
                setHits(null);
                setOpen(false);
              }}
              className="flex items-center gap-3 rounded-sm px-2.5 py-2 transition-colors hover:bg-paper-2"
            >
              <MiniCover title={b.title} src={b.coverUrl} />
              <div className="min-w-0">
                <p className="display truncate text-[15px] leading-tight">{b.title}</p>
                <p className="truncate text-xs text-ink-2">
                  {b.author}
                  {b.year ? ` · ${b.year}` : ""}
                  {b.avg ? ` · ${b.avg.toFixed(1)}★` : ""}
                </p>
              </div>
              <span className="kicker ml-auto shrink-0 text-ink-3">Local</span>
            </Link>
          ))}
          {hits?.authors.map((a) => (
            <Link
              key={a.slug}
              href={`/authors/${a.slug}`}
              onClick={() => {
                setHits(null);
                setOpen(false);
              }}
              className="flex items-center gap-3 rounded-sm px-2.5 py-2 transition-colors hover:bg-paper-2"
            >
              <span className="display flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-paper-3 text-xs text-ink">
                {a.name.charAt(0)}
              </span>
              <div className="min-w-0">
                <p className="display truncate text-[15px] leading-tight">{a.name}</p>
                <p className="text-xs text-ink-2">
                  {a.bookCount} {a.bookCount === 1 ? "book" : "books"} in the stacks
                </p>
              </div>
              <span className="kicker ml-auto shrink-0 text-ink-3">Author</span>
            </Link>
          ))}
          <button
            onClick={goFull}
            className="mt-1 flex w-full items-center gap-2.5 rounded-sm bg-ink px-3.5 py-2.5 text-left text-paper transition-colors hover:bg-rust"
          >
            <Globe2 size={14} />
            <span className="text-xs font-semibold uppercase tracking-[0.14em]">
              Search the whole Open Library for “{q.trim()}”
            </span>
          </button>
        </div>
      )}
    </div>
  );
}

function MiniCover({ title, src }: { title: string; src: string | null }) {
  if (src) {
    // eslint-disable-next-line @next/next/no-img-element
    return (
      <img
        src={src.replace("-L.jpg", "-S.jpg")}
        alt=""
        className="h-9 w-6 shrink-0 rounded-[2px] object-cover ring-1 ring-ink/10"
        loading="lazy"
      />
    );
  }
  return (
    <span className="display flex h-9 w-6 shrink-0 items-center justify-center rounded-[2px] bg-paper-3 text-[10px] text-ink-2 ring-1 ring-ink/10">
      {title.charAt(0)}
    </span>
  );
}
