"use client";

import { useState } from "react";
import { cn, hashHue } from "@/lib/utils";

export function AuthorPortrait({
  name,
  src,
  className,
  imgClassName,
}: {
  name: string;
  src: string | null;
  className?: string;
  imgClassName?: string;
}) {
  const [failed, setFailed] = useState(false);
  const showImage = !!src && !failed;
  const hue = hashHue(name);
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("");

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-[3px] ring-1 ring-ink/10",
        className,
      )}
    >
      {showImage ? (
        <>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={src!}
            alt={name}
            loading="lazy"
            decoding="async"
            onError={() => setFailed(true)}
            className={cn("portrait h-full w-full object-cover", imgClassName)}
          />
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/25 via-transparent to-transparent mix-blend-multiply"
          />
        </>
      ) : (
        <div
          className="flex h-full w-full flex-col items-center justify-center gap-1"
          style={{
            background: `radial-gradient(120% 120% at 30% 20%, hsl(${hue} 30% 86%), hsl(${hue} 26% 76%))`,
          }}
        >
          <span
            className="display text-4xl"
            style={{ color: `hsl(${hue} 30% 26%)` }}
          >
            {initials}
          </span>
          <span
            aria-hidden
            className="h-px w-8"
            style={{ background: `hsl(${hue} 30% 30% / 0.5)` }}
          />
        </div>
      )}
    </div>
  );
}
