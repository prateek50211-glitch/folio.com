import Link from "next/link";
import type { BookMeta } from "@/lib/data";
import { BookCover } from "./BookCover";
import { RatingStars } from "./RatingStars";
import { cn } from "@/lib/utils";

export function BookCard({
  book,
  reason,
  showCommunityRating = true,
  overlay,
  className,
}: {
  book: BookMeta;
  reason?: string | null;
  showCommunityRating?: boolean;
  overlay?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("group relative", className)}>
      <Link href={`/books/${book.slug}`} aria-label={book.title}>
        <div className="lift">
          <BookCover
            title={book.title}
            author={book.author.name}
            src={book.coverUrl}
          />
        </div>
        <div className="mt-3 space-y-1">
          <p className="display line-clamp-2 text-[15px] leading-[1.15]">
            {book.title}
          </p>
          <p className="text-xs text-ink-2">{book.author.name}</p>
          {showCommunityRating && book.avgRating && (
            <p className="flex items-center gap-1.5 pt-0.5">
              <RatingStars rating={book.avgRating} size={10} gap={1.5} />
              <span className="text-[11px] tabular-nums text-ink-3">
                {book.avgRating.toFixed(1)}
              </span>
            </p>
          )}
          {reason && (
            <p className="pt-0.5 text-[11px] italic leading-snug text-ink-3">
              {reason}
            </p>
          )}
        </div>
      </Link>
      {overlay}
    </div>
  );
}

export function BookRail({
  books,
  reasons,
  cardClassName,
}: {
  books: { book: BookMeta; reason?: string | null }[];
  reasons?: boolean;
  cardClassName?: string;
}) {
  return (
    <div className="no-scrollbar -mx-5 flex snap-x gap-5 overflow-x-auto scroll-px-5 px-5 pb-2 pt-1 sm:-mx-8 sm:px-8">
      {books.map(({ book, reason }) => (
        <div
          key={book.id}
          className="w-[132px] shrink-0 snap-start sm:w-[148px]"
        >
          <BookCard book={book} reason={reasons ? reason : undefined} className={cardClassName} />
        </div>
      ))}
      <div className="w-1 shrink-0" />
    </div>
  );
}

export function BookGrid({
  books,
  reasons,
  className,
}: {
  books: { book: BookMeta; reason?: string | null }[];
  reasons?: boolean;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "grid grid-cols-3 gap-x-4 gap-y-8 sm:grid-cols-4 sm:gap-x-5 md:grid-cols-5 lg:grid-cols-6",
        className,
      )}
    >
      {books.map(({ book, reason }) => (
        <BookCard key={book.id} book={book} reason={reasons ? reason : undefined} />
      ))}
    </div>
  );
}
