"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/books", label: "Books" },
  { href: "/authors", label: "Authors" },
  { href: "/for-you", label: "For You" },
  { href: "/readers", label: "Readers" },
];

export function HeaderNav() {
  const pathname = usePathname();
  return (
    <nav className="flex items-center gap-5 sm:gap-7">
      {LINKS.map((l) => {
        const active = pathname.startsWith(l.href);
        return (
          <Link
            key={l.href}
            href={l.href}
            className={cn(
              "kicker relative pb-1 transition-colors",
              active ? "text-ink" : "text-ink-3 hover:text-ink",
            )}
          >
            {l.label}
            <span
              className={cn(
                "absolute -bottom-px left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-rust transition-opacity",
                active ? "opacity-100" : "opacity-0",
              )}
              aria-hidden
            />
          </Link>
        );
      })}
    </nav>
  );
}
