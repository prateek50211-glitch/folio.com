"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Bookmark } from "lucide-react";
import { quickStatusAction } from "@/app/actions";
import { cn } from "@/lib/utils";

export function WantToggle({
  bookId,
  active,
  hasUser,
}: {
  bookId: string;
  active: boolean;
  hasUser: boolean;
}) {
  const router = useRouter();
  const [pending, start] = useTransition();

  return (
    <button
      disabled={pending}
      onClick={() => {
        if (!hasUser) {
          router.push("/sign-in");
          return;
        }
        start(async () => {
          await quickStatusAction(bookId, "want");
        });
      }}
      className={cn(
        "flex w-full items-center justify-center gap-2 rounded-full border py-3 text-xs font-semibold uppercase tracking-[0.16em] transition-all disabled:opacity-60",
        active
          ? "border-rust bg-rust/10 text-rust"
          : "border-ink/20 text-ink-2 hover:border-ink hover:text-ink",
      )}
    >
      <Bookmark size={13} fill={active ? "currentColor" : "none"} strokeWidth={1.8} />
      {active ? "On your shelf" : "Want to read"}
    </button>
  );
}
