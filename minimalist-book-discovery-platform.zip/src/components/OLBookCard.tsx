import type { OLBookPayload } from "@/lib/openlibrary";
import { BookCover } from "./BookCover";
import { InscribeButton, OpenPageButton } from "./OLActions";
import { Globe2 } from "lucide-react";

export function OLBookCard({
  payload,
  hasUser,
  localSlug,
}: {
  payload: OLBookPayload;
  hasUser: boolean;
  localSlug: string | null;
}) {
  return (
    <div className="group flex flex-col">
      <div className="lift relative">
        <BookCover title={payload.title} author={payload.authorName} src={payload.coverUrl} />
        <span className="absolute right-1.5 top-1.5 flex items-center gap-1 rounded-full bg-ink/80 px-2 py-1 text-[8px] font-semibold uppercase tracking-[0.12em] text-paper backdrop-blur-sm">
          <Globe2 size={8} /> OL
        </span>
      </div>
      <p className="display mt-3 line-clamp-2 text-[15px] leading-[1.15]">{payload.title}</p>
      <p className="mt-0.5 text-xs text-ink-2">
        {payload.authorName}
        {payload.year ? ` · ${payload.year}` : ""}
      </p>
      <div className="mt-3 grid grid-cols-2 gap-1.5">
        <InscribeButton payload={payload} hasUser={hasUser} initiallyLogged={!!localSlug} />
        <OpenPageButton payload={payload} hasUser={hasUser} />
      </div>
    </div>
  );
}
