"use client";

import { useFormStatus } from "react-dom";
import { signInAction } from "@/app/actions";
import { Feather } from "lucide-react";

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      disabled={pending}
      className="w-full rounded-full bg-ink py-3.5 text-xs font-semibold uppercase tracking-[0.18em] text-paper transition-colors hover:bg-rust disabled:opacity-60"
    >
      {pending ? "Opening the door…" : "Enter the stacks"}
    </button>
  );
}

export function SignInForm({ error }: { error?: string }) {
  return (
    <form action={signInAction} className="mt-8 space-y-5">
      <div>
        <label
          htmlFor="username"
          className="kicker mb-2 block text-ink-2"
        >
          Name or pen name
        </label>
        <div className="flex items-center gap-3 border-b-2 border-ink/70 pb-2 focus-within:border-rust">
          <Feather size={17} className="text-ink-3" />
          <input
            id="username"
            name="username"
            autoComplete="off"
            autoFocus
            maxLength={40}
            placeholder="e.g. itsalwaysbeenyou"
            className="w-full bg-transparent text-xl outline-none placeholder:text-ink-3"
          />
        </div>
        <p className="mt-2 text-xs leading-relaxed text-ink-3">
          No password, no email. This is a reading room, not a bank — a name is
          enough to open your shelf (or reopen an old one).
        </p>
        {error === "short" && (
          <p className="mt-2 text-xs font-medium text-rust">
            Give us at least two letters to work with.
          </p>
        )}
      </div>
      <SubmitButton />
    </form>
  );
}
