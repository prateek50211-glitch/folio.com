import Link from "next/link";
import { ArrowUpRight } from "lucide-react";

export function SectionHead({
  index,
  title,
  sub,
  href,
  hrefLabel = "See all",
}: {
  index?: string;
  title: string;
  sub?: string;
  href?: string;
  hrefLabel?: string;
}) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4 border-t border-ink/15 pt-4">
      <div>
        {index && (
          <p className="kicker mb-1.5 text-rust">
            <span className="text-ink-3">№ {index}</span> {" · "}
            <span>{sub ?? ""}</span>
          </p>
        )}
        <h2 className="display text-2xl leading-none sm:text-[2rem]">{title}</h2>
      </div>
      {href && (
        <Link
          href={href}
          className="group mb-0.5 flex shrink-0 items-center gap-1 text-xs font-semibold uppercase tracking-[0.16em] text-ink-2 transition-colors hover:text-rust"
        >
          {hrefLabel}
          <ArrowUpRight
            size={14}
            className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
          />
        </Link>
      )}
    </div>
  );
}
