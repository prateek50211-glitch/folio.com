import Link from "next/link";
import type { FriendActivity as FriendActivityType } from "@/lib/data";
import { Avatar } from "./Avatar";
import { BookCover } from "./BookCover";
import { RatingStars } from "./RatingStars";
import { timeAgo } from "@/lib/utils";
import { Heart } from "lucide-react";

export function FriendActivityCard({ act }: { act: FriendActivityType }) {
  const rating = act.log.rating ? parseFloat(act.log.rating) : null;
  return (
    <Link
      href={`/books/${act.book.slug}`}
      className="group flex gap-3.5 border-t border-ink/10 pt-4"
    >
      <div className="w-11 shrink-0">
        <BookCover title={act.book.title} author={act.book.author.name} src={act.book.coverUrl} />
      </div>
      <div className="min-w-0">
        <p className="text-sm leading-snug text-ink-2">
          <span className="font-medium text-ink transition-colors group-hover:text-rust">
            {act.user.displayName}
          </span>{" "}
          finished
        </p>
        <p className="display mt-0.5 line-clamp-1 text-base leading-tight">{act.book.title}</p>
        <p className="mt-1.5 flex items-center gap-2 text-xs text-ink-3">
          {rating && <RatingStars rating={rating} size={10} gap={1.5} />}
          {act.log.liked && <Heart size={10} className="text-rust" fill="currentColor" />}
          {timeAgo(act.log.createdAt)}
        </p>
      </div>
    </Link>
  );
}
