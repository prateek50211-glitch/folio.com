import Link from "next/link";
import type { AuthorIndexEntry } from "@/lib/data";
import { AuthorPortrait } from "./AuthorPortrait";
import { cn, plural } from "@/lib/utils";

export function AuthorCard({
  author,
  className,
}: {
  author: AuthorIndexEntry;
  className?: string;
}) {
  return (
    <Link href={`/authors/${author.slug}`} className={cn("group block", className)}>
      <div className="lift">
        <AuthorPortrait
          name={author.name}
          src={author.photoUrl}
          className="aspect-[3/4] w-full"
        />
      </div>
      <p className="display mt-3 text-lg leading-tight">{author.name}</p>
      <p className="mt-1 text-xs text-ink-2">
        {author.nationality}
        {author.born ? ` · ${author.born}` : ""}
      </p>
      <p className="mt-0.5 text-[11px] uppercase tracking-[0.14em] text-ink-3">
        {plural(author.bookCount, "book")} · {plural(author.readTotal, "read")}
      </p>
    </Link>
  );
}
