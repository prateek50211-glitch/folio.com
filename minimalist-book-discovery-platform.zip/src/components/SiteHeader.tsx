import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { signOutAction } from "@/app/actions";
import { HeaderNav } from "./HeaderNav";
import { SearchBox } from "./SearchBox";
import { Avatar } from "./Avatar";
import { LogOut } from "lucide-react";

export async function SiteHeader() {
  const user = await getSessionUser();
  return (
    <header className="sticky top-0 z-40 border-b border-ink/10 bg-paper/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-[1240px] items-center justify-between gap-4 px-5 sm:px-8">
        <div className="flex items-center gap-8">
          <Link href="/" className="group flex items-baseline gap-[3px]">
            <span className="display text-[26px] leading-none tracking-tight">
              Folio
            </span>
            <span className="h-1.5 w-1.5 rounded-full bg-rust transition-transform duration-300 group-hover:scale-150" />
          </Link>
          <div className="hidden md:block">
            <HeaderNav />
          </div>
        </div>
        <div className="flex items-center gap-2 sm:gap-3">
          <SearchBox />
          {user ? (
            <div className="flex items-center gap-2">
              <Link
                href="/you"
                className="flex items-center gap-2 rounded-full py-1 pl-1 pr-3 transition-colors hover:bg-paper-2"
                title="Your shelf"
              >
                <Avatar name={user.displayName} className="h-7 w-7" />
                <span className="hidden text-sm font-medium sm:block">
                  {user.displayName.split(" ")[0]}
                </span>
              </Link>
              <form action={signOutAction}>
                <button
                  type="submit"
                  aria-label="Sign out"
                  title="Sign out"
                  className="flex h-8 w-8 items-center justify-center rounded-full text-ink-3 transition-colors hover:bg-paper-2 hover:text-rust"
                >
                  <LogOut size={15} />
                </button>
              </form>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/sign-in"
                className="kicker px-2 py-1 text-ink-2 transition-colors hover:text-ink"
              >
                Sign in
              </Link>
              <Link
                href="/sign-in"
                className="rounded-full bg-ink px-4 py-2 text-xs font-semibold tracking-[0.14em] text-paper uppercase transition-colors hover:bg-rust"
              >
                Join
              </Link>
            </div>
          )}
        </div>
      </div>
      <div className="border-t border-ink/5 md:hidden">
        <div className="mx-auto flex h-11 max-w-[1240px] items-center px-5">
          <HeaderNav />
        </div>
      </div>
    </header>
  );
}
