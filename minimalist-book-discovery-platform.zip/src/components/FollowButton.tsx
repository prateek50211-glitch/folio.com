"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Check, Plus } from "lucide-react";
import { followAction } from "@/app/actions";
import { cn } from "@/lib/utils";

export function FollowButton({
  username,
  initiallyFollowing,
  hasUser,
  size = "md",
}: {
  username: string;
  initiallyFollowing: boolean;
  hasUser: boolean;
  size?: "sm" | "md";
}) {
  const router = useRouter();
  const [following, setFollowing] = useState(initiallyFollowing);
  const [pending, start] = useTransition();

  return (
    <button
      disabled={pending}
      onClick={() => {
        if (!hasUser) {
          router.push("/sign-in");
          return;
        }
        setFollowing((f) => !f);
        start(async () => {
          const res = await followAction(username);
          if (res.ok) setFollowing(res.following);
          else if (res.error === "signin") router.push("/sign-in");
          else setFollowing(initiallyFollowing);
        });
      }}
      className={cn(
        "flex items-center gap-1.5 rounded-full font-semibold uppercase transition-all disabled:opacity-60",
        size === "sm"
          ? "px-3.5 py-1.5 text-[10px] tracking-[0.12em]"
          : "px-5 py-2.5 text-[11px] tracking-[0.16em]",
        following
          ? "border border-rust/50 bg-rust/10 text-rust"
          : "bg-ink text-paper hover:bg-rust",
      )}
    >
      {following ? <Check size={12} /> : <Plus size={12} />}
      {following ? "Following" : "Follow"}
    </button>
  );
}
