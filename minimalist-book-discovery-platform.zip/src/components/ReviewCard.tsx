import Link from "next/link";
import { Heart } from "lucide-react";
import type { ReviewWithMeta } from "@/lib/data";
import { Avatar } from "./Avatar";
import { RatingStars } from "./RatingStars";
import { BookCover } from "./BookCover";
import { timeAgo } from "@/lib/utils";

export function ReviewRow({ review }: { review: ReviewWithMeta }) {
  const rating = review.log.rating ? parseFloat(review.log.rating) : null;
  return (
    <article className="border-t border-ink/10 py-5 first:border-t-0 first:pt-0">
      <div className="flex items-center gap-2.5">
        <Avatar name={review.user.displayName} />
        <p className="text-sm font-medium">{review.user.displayName}</p>
        <span className="text-ink-3">·</span>
        <p className="text-xs text-ink-3">@{review.user.username}</p>
        <div className="ml-auto flex items-center gap-2">
          {rating && <RatingStars rating={rating} size={11} gap={1.5} />}
          {review.log.liked && (
            <Heart size={11} className="text-rust" fill="currentColor" />
          )}
          <span className="text-[11px] text-ink-3">
            {timeAgo(review.log.createdAt)}
          </span>
        </div>
      </div>
      <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-ink/90">
        {review.log.review}
      </p>
    </article>
  );
}

export function ReviewTeaser({ review }: { review: ReviewWithMeta }) {
  const rating = review.log.rating ? parseFloat(review.log.rating) : null;
  return (
    <Link
      href={`/books/${review.book.slug}`}
      className="group flex h-full flex-col border-t border-ink/15 pt-4"
    >
      <p className="display flex-1 text-[17px] leading-snug">
        “{review.log.review}”
      </p>
      <div className="mt-5 flex items-center gap-3">
        <div className="w-10 shrink-0">
          <BookCover
            title={review.book.title}
            author={review.book.author.name}
            src={review.book.coverUrl}
          />
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium transition-colors group-hover:text-rust">
            {review.book.title}
          </p>
          <p className="mt-0.5 flex items-center gap-1.5 text-xs text-ink-2">
            {review.user.displayName}
            {rating && (
              <>
                <span className="text-ink-3">·</span>
                <RatingStars rating={rating} size={9} gap={1} />
              </>
            )}
          </p>
        </div>
      </div>
    </Link>
  );
}
