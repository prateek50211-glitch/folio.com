import { cn, hashHue } from "@/lib/utils";

export function Avatar({
  name,
  className,
}: {
  name: string;
  className?: string;
}) {
  const hue = hashHue(name);
  const initial = name.trim().charAt(0).toUpperCase() || "R";
  return (
    <span
      className={cn(
        "display inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs ring-1 ring-ink/10",
        className,
      )}
      style={{
        background: `hsl(${hue} 30% 84%)`,
        color: `hsl(${hue} 34% 28%)`,
      }}
      aria-hidden
    >
      {initial}
    </span>
  );
}
