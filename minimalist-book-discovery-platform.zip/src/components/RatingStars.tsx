import { cn } from "@/lib/utils";

const STAR_PATH =
  "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z";

export function StarSvg({
  size,
  filled,
  className,
}: {
  size: number;
  filled: boolean;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      className={className}
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={filled ? 0 : 1.6}
      strokeLinejoin="round"
      aria-hidden
    >
      <path d={STAR_PATH} />
    </svg>
  );
}

export function RatingStars({
  rating,
  size = 12,
  className,
  gap = 2,
}: {
  rating: number | null;
  size?: number;
  className?: string;
  gap?: number;
}) {
  const pct = Math.max(0, Math.min(1, (rating ?? 0) / 5)) * 100;
  return (
    <span
      className={cn("relative inline-flex shrink-0 text-ink/25", className)}
      role="img"
      aria-label={rating ? `${rating} out of 5 stars` : "Not rated"}
    >
      <span className="flex" style={{ gap }}>
        {[...Array(5)].map((_, i) => (
          <StarSvg key={i} size={size} filled={false} />
        ))}
      </span>
      <span
        className="absolute inset-y-0 left-0 overflow-hidden text-star"
        style={{ width: `${pct}%` }}
      >
        <span className="flex" style={{ gap }}>
          {[...Array(5)].map((_, i) => (
            <StarSvg key={i} size={size} filled />
          ))}
        </span>
      </span>
    </span>
  );
}
