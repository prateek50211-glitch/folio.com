"use client";

import { useState } from "react";
import { StarSvg } from "./RatingStars";

export function StarInput({
  value,
  onChange,
  size = 26,
}: {
  value: number | null;
  onChange: (v: number | null) => void;
  size?: number;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const shown = hover ?? value ?? 0;
  const pct = (shown / 5) * 100;

  return (
    <div className="flex items-center gap-3">
      <div
        className="relative inline-flex"
        onMouseLeave={() => setHover(null)}
        role="radiogroup"
        aria-label="Your rating"
      >
        <div className="flex gap-1.5 text-ink/25">
          {[...Array(5)].map((_, i) => (
            <StarSvg key={i} size={size} filled={false} />
          ))}
        </div>
        <div
          className="pointer-events-none absolute inset-y-0 left-0 overflow-hidden text-star transition-[width] duration-75"
          style={{ width: `${pct}%` }}
        >
          <div className="flex gap-1.5">
            {[...Array(5)].map((_, i) => (
              <StarSvg key={i} size={size} filled />
            ))}
          </div>
        </div>
        <div className="absolute inset-0 flex">
          {[...Array(5)].map((_, starIdx) => {
            const star = starIdx + 1;
            return (
              <span key={starIdx} className="flex" style={{ width: size + 6 }}>
                <button
                  type="button"
                  aria-label={`${star - 0.5} stars`}
                  className="h-full"
                  style={{ width: (size + 6) / 2 }}
                  onMouseEnter={() => setHover(star - 0.5)}
                  onClick={() => onChange(star - 0.5)}
                />
                <button
                  type="button"
                  aria-label={`${star} stars`}
                  className="h-full"
                  style={{ width: (size + 6) / 2 }}
                  onMouseEnter={() => setHover(star)}
                  onClick={() => onChange(star)}
                />
              </span>
            );
          })}
        </div>
      </div>
      {value ? (
        <button
          type="button"
          onClick={() => onChange(null)}
          className="kicker text-ink-3 hover:text-rust transition-colors"
        >
          Clear
        </button>
      ) : (
        <span className="kicker text-ink-3">Tap a star</span>
      )}
    </div>
  );
}
