import type { BookMeta } from "@/lib/data";
import { BookCover } from "./BookCover";

export function MarqueeCovers({
  top,
  bottom,
}: {
  top: BookMeta[];
  bottom: BookMeta[];
}) {
  return (
    <div
      className="relative -rotate-1 select-none space-y-4 overflow-hidden py-6"
      style={{
        maskImage:
          "linear-gradient(90deg, transparent, black 8%, black 92%, transparent)",
        WebkitMaskImage:
          "linear-gradient(90deg, transparent, black 8%, black 92%, transparent)",
      }}
    >
      <Row books={top} reverse={false} />
      <Row books={bottom} reverse />
    </div>
  );
}

function Row({ books, reverse }: { books: BookMeta[]; reverse: boolean }) {
  const doubled = [...books, ...books];
  return (
    <div
      className={`flex w-max gap-4 ${reverse ? "animate-[marquee-rev_70s_linear_infinite]" : "animate-[marquee_70s_linear_infinite]"}`}
    >
      {doubled.map((b, i) => (
        <div key={`${b.id}-${i}`} className="w-[96px] shrink-0 sm:w-[112px]">
          <BookCover title={b.title} author={b.author.name} src={b.coverUrl} />
        </div>
      ))}
    </div>
  );
}
