import Link from "next/link";

const COLS: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: "Explore",
    links: [
      { href: "/books", label: "All books" },
      { href: "/authors", label: "All authors" },
      { href: "/for-you", label: "For you" },
      { href: "/readers", label: "Readers" },
      { href: "/search", label: "Search" },
    ],
  },
  {
    title: "Your shelf",
    links: [
      { href: "/you", label: "Reading diary" },
      { href: "/you#want", label: "Want to read" },
      { href: "/you#reviews", label: "Your reviews" },
      { href: "/sign-in", label: "Sign in" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="mt-24 border-t border-ink/10 bg-ink text-paper">
      <div className="mx-auto max-w-[1240px] px-5 py-14 sm:px-8">
        <div className="flex flex-col gap-10 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="display text-[clamp(4rem,12vw,9rem)] leading-[0.85] text-paper/95">
              Folio<span className="text-rust">.</span>
            </p>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-paper/60">
              A quiet social home for readers. Keep every story you’ve ever met —
              and let the right one find you next.
            </p>
          </div>
          <div className="flex gap-16">
            {COLS.map((col) => (
              <div key={col.title}>
                <p className="kicker mb-4 text-paper/40">{col.title}</p>
                <ul className="space-y-2.5">
                  {col.links.map((l) => (
                    <li key={l.href + l.label}>
                      <Link
                        href={l.href}
                        className="u-sweep text-sm text-paper/75 transition-colors hover:text-paper"
                      >
                        {l.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-12 flex flex-col gap-2 border-t border-paper/15 pt-6 text-xs text-paper/40 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Folio Garden. Read responsibly.</p>
          <p>Covers courtesy of Open Library · Portraits via Wikimedia</p>
        </div>
      </div>
    </footer>
  );
}
