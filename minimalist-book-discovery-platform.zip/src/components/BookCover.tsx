"use client";

import { useState } from "react";
import { cn, hashHue } from "@/lib/utils";

/**
 * A book cover. If a real cover image exists, shows it with a soft sheen;
 * otherwise renders an elegant typographic "reissue" cover derived from the title.
 */
export function BookCover({
  title,
  author,
  src,
  className,
  eager = false,
}: {
  title: string;
  author: string;
  src: string | null;
  className?: string;
  eager?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const showImage = !!src && !failed;

  return (
    <div
      className={cn(
        "relative aspect-[2/3] w-full select-none overflow-hidden rounded-[3px] ring-1 ring-ink/10 shadow-[0_2px_6px_-2px_rgba(23,19,13,0.25)]",
        className,
      )}
    >
      {showImage ? (
        <>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={src}
            alt={title}
            loading={eager ? "eager" : "lazy"}
            decoding="async"
            onError={() => setFailed(true)}
            className="h-full w-full object-cover"
          />
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 bg-gradient-to-br from-white/12 via-transparent to-ink/10"
          />
          <div
            aria-hidden
            className="pointer-events-none absolute inset-y-0 left-0 w-[7%] bg-gradient-to-r from-ink/25 via-ink/5 to-transparent"
          />
        </>
      ) : (
        <TypographicCover title={title} author={author} />
      )}
    </div>
  );
}

function TypographicCover({ title, author }: { title: string; author: string }) {
  const hue = hashHue(title + author);
  const bg = `linear-gradient(160deg, hsl(${hue} 32% 89%) 0%, hsl(${hue} 26% 82%) 100%)`;
  const ink = `hsl(${hue} 34% 20%)`;
  return (
    <div
      className="flex h-full w-full flex-col justify-between p-[10%]"
      style={{ background: bg }}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-y-0 left-0 w-[8%]"
        style={{
          background: `linear-gradient(90deg, hsl(${hue} 34% 18% / 0.35), hsl(${hue} 34% 18% / 0) 100%)`,
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-[7%] rounded-[2px] border"
        style={{ borderColor: `hsl(${hue} 34% 22% / 0.25)` }}
      />
      <p
        className="display relative mt-[10%] text-center leading-[1.06]"
        style={{
          color: ink,
          fontSize: "clamp(0.62rem, 1.05vw + 0.5rem, 1.05rem)",
        }}
      >
        {title.length > 42 ? title.slice(0, 42).trimEnd() + "…" : title}
      </p>
      <p
        className="relative text-center text-[7px] font-semibold uppercase tracking-[0.18em]"
        style={{ color: `hsl(${hue} 26% 34%)` }}
      >
        {author}
      </p>
    </div>
  );
}
