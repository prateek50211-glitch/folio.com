import "dotenv/config";
import { db } from "../src/db";
import { authors, books, logs, sessions, users } from "../src/db/schema";
import {
  AUTHORS,
  BOOKS,
  PERSONAS,
  REVIEW_SNIPPETS,
  GENRES,
} from "../src/db/seed-data";
import { sql } from "drizzle-orm";

// ---------- deterministic PRNG ----------
function mulberry32(seed: number) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(20260214);

function pick<T>(arr: T[]): T {
  return arr[Math.floor(rand() * arr.length)];
}

function slugify(s: string) {
  return s
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function fetchJson(url: string): Promise<any | null> {
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(9000),
      headers: {
        "User-Agent": "FolioGarden/1.0 (seed script; contact: hello@foliagarden.app)",
        Accept: "application/json",
      },
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function fetchAuthorPhoto(name: string): Promise<string | null> {
  const data = await fetchJson(
    `https://en.wikipedia.org/w/api.php?action=query&format=json&redirects=1&prop=pageimages&piprop=original&titles=${encodeURIComponent(name)}`,
  );
  const pages = data?.query?.pages;
  if (!pages) return null;
  const first = Object.values(pages)[0] as any;
  const src: string | undefined = first?.original?.source ?? first?.thumbnail?.source;
  if (!src) return null;
  if (src.toLowerCase().endsWith(".svg")) return null;
  return src;
}

async function fetchBookCover(title: string, author: string): Promise<string | null> {
  const data = await fetchJson(
    `https://openlibrary.org/search.json?title=${encodeURIComponent(title)}&author=${encodeURIComponent(author)}&fields=cover_i&limit=5`,
  );
  const docs: any[] = data?.docs ?? [];
  const withCover = docs.find((d) => typeof d.cover_i === "number");
  if (!withCover) return null;
  return `https://covers.openlibrary.org/b/id/${withCover.cover_i}-L.jpg`;
}

async function mapPool<T, R>(items: T[], size: number, fn: (item: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let i = 0;
  const workers = Array.from({ length: Math.min(size, items.length) }, async () => {
    while (i < items.length) {
      const idx = i++;
      out[idx] = await fn(items[idx], idx);
    }
  });
  await Promise.all(workers);
  return out;
}

function roundHalf(n: number) {
  return Math.round(n * 2) / 2;
}
function clamp(n: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, n));
}

async function main() {
  console.log("↺ clearing tables…");
  await db.delete(logs);
  await db.delete(sessions);
  await db.delete(books);
  await db.delete(authors);
  await db.delete(users);

  // ---------- authors ----------
  console.log(`↺ fetching author portraits (${AUTHORS.length})…`);
  const authorRows = await mapPool(AUTHORS, 5, async (a) => {
    const photoUrl = await fetchAuthorPhoto(a.name);
    return {
      name: a.name,
      slug: slugify(a.name),
      bio: a.bio,
      born: a.born,
      nationality: a.nationality,
      photoUrl,
    };
  });
  const withPhotos = authorRows.filter((a) => a.photoUrl).length;
  console.log(`  ✓ ${withPhotos}/${authorRows.length} portraits found`);
  const insertedAuthors = await db.insert(authors).values(authorRows).returning();
  const authorByName = new Map(insertedAuthors.map((a) => [a.name, a]));

  // ---------- books ----------
  console.log(`↺ fetching covers from Open Library (${BOOKS.length})…`);
  let coversFound = 0;
  const bookRows = await mapPool(BOOKS, 5, async (b, i) => {
    const author = authorByName.get(b.author);
    if (!author) throw new Error(`Missing author: ${b.author}`);
    const coverUrl = await fetchBookCover(b.title, b.author);
    if (coverUrl) coversFound++;
    if (i % 12 === 0) await sleep(150);
    return {
      title: b.title,
      slug: slugify(`${b.title}-${b.author}`),
      authorId: author.id,
      description: b.blurb,
      coverUrl,
      publishedYear: b.year,
      pages: b.pages,
      genres: b.genres,
      heat: b.heat,
    };
  });
  const insertedBooks = await db.insert(books).values(bookRows).returning();
  console.log(`  ✓ ${coversFound}/${bookRows.length} covers found`);
  const bookByTitle = new Map(insertedBooks.map((b) => [b.title, b]));

  // ---------- users ----------
  const personaRows = PERSONAS.map((p) => ({
    username: p.username,
    displayName: p.displayName,
  }));
  const insertedUsers = await db.insert(users).values(personaRows).returning();

  // ---------- logs ----------
  console.log("↺ generating reading logs…");
  const genreWeights = insertedUsers.map(() => {
    const m = new Map<string, number>();
    for (const g of GENRES) m.set(g, 0.15 + rand() * 0.85);
    // pick 2 obsessions
    const shuffled = [...GENRES].sort(() => rand() - 0.5);
    m.set(shuffled[0], 1);
    m.set(shuffled[1], 0.95);
    return m;
  });

  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;
  const logRows: (typeof logs.$inferInsert)[] = [];
  const seen = new Set<string>();

  function createdAtFor(): Date {
    const r = rand();
    if (r < 0.3) return new Date(now - rand() * 7 * day);
    if (r < 0.6) return new Date(now - (7 + rand() * 30) * day);
    return new Date(now - (37 + rand() * 150) * day);
  }

  insertedUsers.forEach((u, ui) => {
    const persona = PERSONAS[ui];
    const weights = genreWeights[ui];
    const target = 24 + Math.floor(rand() * 24);

    const scored = insertedBooks
      .map((b) => {
        const gs = b.genres.reduce((s, g) => s + (weights.get(g) ?? 0.3), 0) / b.genres.length;
        const appeal = gs * 0.52 + (b.heat / 10) * 0.42 + rand() * 0.16;
        return { b, appeal };
      })
      .sort((a, z) => z.appeal - a.appeal);

    const chosen = scored.slice(0, target);
    // keep every persona logging a handful of hot books
    const hot = scored.filter((s) => s.b.heat >= 9 && !chosen.includes(s)).slice(0, 4);
    for (const h of hot) chosen.push(h);

    for (const { b, appeal } of chosen) {
      const key = `${u.id}:${b.id}`;
      if (seen.has(key)) continue;
      seen.add(key);

      const roll = rand();
      const status: "read" | "reading" | "want" =
        roll < 0.78 ? "read" : roll < 0.88 ? "want" : "reading";
      const created = createdAtFor();

      if (status === "read") {
        let rating =
          persona.base + (appeal - 0.55) * 1.7 + (rand() - 0.5) * 1.1;
        rating = clamp(roundHalf(rating), 1, 5);
        const liked = rating >= 4.5 && rand() < 0.45;
        const review =
          rand() < 0.3 ? pick(REVIEW_SNIPPETS) : null;
        logRows.push({
          userId: u.id,
          bookId: b.id,
          status,
          rating: rating.toFixed(1),
          liked,
          review,
          createdAt: created,
          updatedAt: created,
        });
      } else {
        logRows.push({
          userId: u.id,
          bookId: b.id,
          status,
          rating: null,
          liked: false,
          review: null,
          createdAt: created,
          updatedAt: created,
        });
      }
    }
  });

  // top-up pass so almost every book has a pulse
  for (const b of insertedBooks) {
    const count = logRows.filter((l) => l.bookId === b.id).length;
    const want = Math.min(6, Math.max(1, Math.round(b.heat / 2.2)));
    let need = want - count;
    while (need > 0) {
      const ui = Math.floor(rand() * insertedUsers.length);
      const u = insertedUsers[ui];
      const persona = PERSONAS[ui];
      const key = `${u.id}:${b.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const created = new Date(now - rand() * 40 * day);
      if (rand() < 0.75) {
        let rating = clamp(
          roundHalf(persona.base + (rand() - 0.35) * 1.4 + (b.heat - 6) * 0.12),
          1,
          5,
        );
        logRows.push({
          userId: u.id,
          bookId: b.id,
          status: "read",
          rating: rating.toFixed(1),
          liked: rating >= 4.5 && rand() < 0.35,
          review: rand() < 0.22 ? pick(REVIEW_SNIPPETS) : null,
          createdAt: created,
          updatedAt: created,
        });
      } else {
        logRows.push({
          userId: u.id,
          bookId: b.id,
          status: "want",
          rating: null,
          liked: false,
          review: null,
          createdAt: created,
          updatedAt: created,
        });
      }
      need--;
    }
  }

  await db.insert(logs).values(logRows);

  const [{ c: bookCount }] = await db
    .select({ c: sql<number>`count(*)` })
    .from(books);
  const [{ c: logCount }] = await db
    .select({ c: sql<number>`count(*)` })
    .from(logs);
  console.log(`✓ seeded ${bookCount} books, ${insertedAuthors.length} authors, ${logCount} logs`);
  process.exit(0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
